﻿using Microsoft.AspNetCore.Mvc;
using IClipsLoginAPI.Models;
using IClipsLoginAPI.Services;

namespace IClipsLoginAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class AuthController : ControllerBase
{
    private readonly IAuthService _auth;
    private readonly IUserService _userSvc;
    private readonly ILogger<AuthController> _logger;

    public AuthController(IAuthService auth, IUserService userSvc,
        ILogger<AuthController> logger)
    { _auth = auth; _userSvc = userSvc; _logger = logger; }

    /// <summary>Login DB → Session Token</summary>
    [HttpPost("login")]
    [ProducesResponseType(typeof(LoginResponse), 200)]
    [ProducesResponseType(401)]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);

        var result = await _auth.LoginAsync(request);
        return result.Success
            ? Ok(result)
            : Unauthorized(new { message = result.Message });
    }

    /// <summary>Get company list untuk dropdown login</summary>
    [HttpGet("companies")]
    [ProducesResponseType(typeof(List<Company>), 200)]
    public async Task<IActionResult> GetCompanies()
        => Ok(await _userSvc.GetAllCompaniesAsync());

    /// <summary>Get profile dari header token (protected)</summary>
    [HttpGet("profile")]
    [ProducesResponseType(typeof(UserProfile), 200)]
    [ProducesResponseType(401)]
    public IActionResult GetProfile()
    {
        // Ambil token dari header Authorization: Bearer {token}
        var token = Request.Headers["Authorization"]
            .ToString().Replace("Bearer ", "").Trim();

        if (string.IsNullOrWhiteSpace(token))
            return Unauthorized(new { message = "Token tidak ditemukan." });

        var session = _auth.GetSession(token);
        if (session == null)
            return Unauthorized(new { message = "Token tidak valid atau sudah expired." });

        return Ok(new UserProfile
        {
            UserID = session.UserID,
            CompanyID = session.CompanyID,
            CompanyName = session.CompanyName,
            DisplayName = session.UserID,
        });
    }

    /// <summary>Validate token masih valid</summary>
    [HttpGet("validate")]
    public IActionResult Validate()
    {
        var token = Request.Headers["Authorization"]
            .ToString().Replace("Bearer ", "").Trim();

        if (string.IsNullOrWhiteSpace(token))
            return Unauthorized(new { valid = false });

        var session = _auth.GetSession(token);
        return session != null
            ? Ok(new { valid = true })
            : Unauthorized(new { valid = false });
    }
}