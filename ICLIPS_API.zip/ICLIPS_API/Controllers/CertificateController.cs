﻿using Microsoft.AspNetCore.Mvc;
using ICLIPS_API.Repositories;
using ICLIPS_API.DTOs;

namespace ICLIPS_API.Controllers
{
    [ApiController]
    [Route("api/certificate")]
    public class CertificateController : ControllerBase
    {
        private readonly ICertificateDetailRepository _repo;

        public CertificateController(ICertificateDetailRepository repo)
        {
            _repo = repo;
        }

        // ── LIST ────────────────────────────────────────────────
        [HttpGet]
        public async Task<IActionResult> GetList([FromQuery] CertificateFilterDto filter)
        {
            var result = await _repo.GetCertificateListAsync(filter);
            return Ok(result);
        }

        [HttpGet("by-member")]
        public async Task<IActionResult> GetByMember([FromQuery] string memberId, [FromQuery] string companyId)
        {
            var result = await _repo.GetByMemberIdAsync(memberId, companyId);
            if (result == null) return NotFound();
            return Ok(result);
        }

        // ── DETAIL ───────────────────────────────────────────────
        [HttpGet("{certificateID}/detail")]
        public async Task<IActionResult> GetDetail(string certificateID)
        {
            var header = await _repo.GetHeaderAsync(certificateID);
            if (header == null) return NotFound(new { message = "Certificate not found" });

            var certInfo = await _repo.GetCertificateInfoAsync(header.MemberID!);
            return Ok(new { header, certInfo });
        }

        [HttpGet("{memberID}/client-agent-beneficiary")]
        public async Task<IActionResult> GetClientAgentBeneficiary(string memberID)
            => Ok(await _repo.GetClientAgentBeneficiaryAsync(memberID));

        [HttpGet("{memberID}/coverage-document")]
        public async Task<IActionResult> GetCoverageDocument(string memberID)
            => Ok(await _repo.GetCoverageDocumentAsync(memberID));

        [HttpGet("{memberID}/financial-health")]
        public async Task<IActionResult> GetFinancialHealth(string memberID)
            => Ok(await _repo.GetFinancialHealthAsync(memberID));

        [HttpGet("{memberID}/policy-history")]
        public async Task<IActionResult> GetPolicyHistory(string memberID)
            => Ok(await _repo.GetPolicyHistoryAsync(memberID));

        [HttpGet("{memberID}/letters")]
        public async Task<IActionResult> GetLetters(string memberID)
            => Ok(await _repo.GetLettersAsync(memberID));

        [HttpGet("{memberID}/activity-history")]
        public async Task<IActionResult> GetActivityHistory(string memberID)
            => Ok(await _repo.GetActivityHistoryAsync(memberID));
    }
}