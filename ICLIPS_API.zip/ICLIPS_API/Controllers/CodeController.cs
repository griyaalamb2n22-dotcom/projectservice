﻿using ICLIPS_API.Services;
using Microsoft.AspNetCore.Mvc;

namespace ICLIPS_API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CodeController : ControllerBase
{
    private readonly ICodeService _svc;
    public CodeController(ICodeService svc) => _svc = svc;

    /// <summary>Get list code dari tdcode</summary>
    [HttpGet]
    public async Task<IActionResult> GetCodes(
        [FromQuery] string companyId,
        [FromQuery] string codeType,
        [FromQuery] string codeCategory = "")
    {
        if (string.IsNullOrWhiteSpace(companyId) || string.IsNullOrWhiteSpace(codeType))
            return BadRequest(new { message = "companyId dan codeType wajib diisi." });

        var result = await _svc.GetCodesAsync(companyId, codeType, codeCategory);
        return Ok(result);
    }
}