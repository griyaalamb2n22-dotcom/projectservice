﻿using ICLIPS_API.Models;
using ICLIPS_API.DTOs;

namespace ICLIPS_API.Repositories
{
    public interface ICertificateDetailRepository
    {
        // ── List (DefaultConnection / NDICLIPS04) ──────────────
        Task<PagedResult<CertificateDto>> GetCertificateListAsync(CertificateFilterDto filter);
        Task<CertificateDto?> GetByMemberIdAsync(string memberId, string companyId);

        // ── Detail (NDISIS02) ──────────────────────────────────
        Task<CertificateHeader?> GetHeaderAsync(string certificateID);
        Task<CertificateInfo?> GetCertificateInfoAsync(string memberID);
        Task<ClientAgentBeneficiaryInfo?> GetClientAgentBeneficiaryAsync(string memberID);
        Task<List<CoverageDocumentInfo>> GetCoverageDocumentAsync(string memberID);
        Task<FinancialHealthInfo?> GetFinancialHealthAsync(string memberID);
        Task<List<PolicyHistoryItem>> GetPolicyHistoryAsync(string memberID);
        Task<List<LetterItem>> GetLettersAsync(string memberID);
        Task<List<ActivityHistoryItem>> GetActivityHistoryAsync(string memberID);
    }
}