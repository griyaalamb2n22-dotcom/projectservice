﻿namespace ICLIPS_API.DTOs
{
    public class CertificateDto
    {
        public string? MemberID { get; set; }
        public string? CompanyID { get; set; }
        public string? PolicyID { get; set; }
        public string? PolicyOwnerName { get; set; }
        public string? ProductType { get; set; }
        public string? ProductTypeName { get; set; }
        public string? CertificateID { get; set; }
        public string? InsuredID { get; set; }
        public string? InsuredName { get; set; }
        public string? CertificateStatus { get; set; }
        public string? CertificateStatusName { get; set; }
        public string? ProgressStatus { get; set; }
        public string? ProgressStatusName { get; set; }
        public DateTime? AppReceiveDate { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? InforceDate { get; set; }
        public string? PendingItem { get; set; }
    }

    public class CertificateFilterDto
    {
        public string? MemberID { get; set; }
        public string? CompanyID { get; set; }
        public string? PolicyID { get; set; }
        public string? CertificateID { get; set; }
        public string? CertificateStatus { get; set; }
        public string? InsuredName { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 20;
        public string? SortColumn { get; set; } = "appReceiveDate";
        public string? SortDirection { get; set; } = "DESC";
    }

    public class PagedResult<T>
    {
        public List<T> Data { get; set; } = new();
        public int TotalRecords { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public int TotalPages => PageSize > 0 ? (int)Math.Ceiling((double)TotalRecords / PageSize) : 0;
    }
}