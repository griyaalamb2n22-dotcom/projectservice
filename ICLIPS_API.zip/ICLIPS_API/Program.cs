using ICLIPS_API.Repositories;
using ICLIPS_API.Services;
using IClipsLoginAPI.Services;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "iCLIPS Login API", Version = "v1" });
});

// ? HAPUS AddAuthorization() jika tidak pakai [Authorize]
// builder.Services.AddAuthorization();

builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<ICodeService, CodeService>();
builder.Services.AddScoped<ICertificateService, CertificateService>();
builder.Services.AddScoped<ICertificateDetailRepository, CertificateDetailRepository>();

builder.Services.AddCors(opt =>
    opt.AddPolicy("AllowAngular", p =>
        p.WithOrigins("http://localhost:4200")
         .AllowAnyHeader()
         .AllowAnyMethod()));

var app = builder.Build();
app.UseSwagger();
app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "iCLIPS API v1"));
app.UseCors("AllowAngular");
app.UseHttpsRedirection();
app.UseAuthentication(); // ? harus ada sebelum UseAuthorization
app.UseAuthorization();
app.MapControllers();
app.Run();