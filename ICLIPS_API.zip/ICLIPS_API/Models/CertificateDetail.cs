﻿namespace ICLIPS_API.Models
{
    public class CertificateHeader
    {
        public string MemberID { get; set; } = "";
        public string CompanyID { get; set; } = "";
        public string PolicyID { get; set; } = "";
        public string? PolicyOwnerName { get; set; }
        public string? ProductType { get; set; }
        public string? ProductTypeName { get; set; }
        public string? PartnerID { get; set; }
        public string? PartnerName { get; set; }
        public string CertificateID { get; set; } = "";
        public string? InsuredID { get; set; }
        public string? InsuredName { get; set; }
        public string? DebiturID { get; set; }
        public string? DebiturName { get; set; }
        public string? CertificateStatus { get; set; }
        public string? CertificateStatusName { get; set; }
        public string? UnderwritingStatus { get; set; }
        public string? UnderwritingStatusName { get; set; }
        public string? PendingTransNo { get; set; }
        public string? PendingTransType { get; set; }
        public string? PendingTransTypeName { get; set; }
        public string? ProgressStatus { get; set; }
        public string? ProgressStatusName { get; set; }
        public string? MedicalType { get; set; }
        public string? PendingItem { get; set; }
        public string? MedicalTypeName { get; set; }
    }

    // Certificate Info tab - dari vCertificate join tcertificate_coverage
    public class CertificateInfo
    {
        public string MemberID { get; set; } = "";
        public string? ApplicationNo { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? AppReceiveDate { get; set; }
        public DateTime? AppSignedDate { get; set; }
        public DateTime? CoverNoteDate { get; set; }
        public bool? JoinIncome { get; set; }
        public string? MainCertificateID { get; set; }
        public string? Currency { get; set; }
        public string? BillingMode { get; set; }
        public decimal? PremiumAmount { get; set; }
        public decimal? PremiumNettAmount { get; set; }
        public decimal? PremiumTaxAmount { get; set; }
        public decimal? PremiumTaxRate { get; set; }
        public string? AgreementNo { get; set; }
        public int? LoanDuration { get; set; }
        public DateTime? LoanMaturityDate { get; set; }
        public decimal? BillAmount { get; set; }
        public string? ExtraPremiumRate { get; set; }
        public decimal? ExtraPremiumAmount { get; set; }
        public decimal? ExtraPremiumNett { get; set; }
        public decimal? TotalPremium { get; set; }
        public decimal? ExtraMortalityRating { get; set; }
        public int? AllowedProcess { get; set; }
        public DateTime? InforceDate { get; set; }
        public decimal? Weight { get; set; }
        public decimal? Height { get; set; }
        public decimal? BMIRate { get; set; }
        public int? Rating { get; set; }
        public string? PrevCertificateID { get; set; }
        public decimal? SurrenderAmount { get; set; }
        public bool? NeedUnderwritingProcess { get; set; }
        public string? Notes { get; set; }
        public string? BasePlan { get; set; }
    }

    public class ClientAgentBeneficiaryInfo
    {
        public string MemberID { get; set; } = "";
        public string? InsuredID { get; set; }
        public string? InsuredName { get; set; }
        public string? InsuredIDNo { get; set; }
        public DateTime? InsuredBirthDate { get; set; }
        public string? InsuredGender { get; set; }
        public string? AgentID { get; set; }
        public string? AgentName { get; set; }
        public string? BeneficiaryName { get; set; }
        public string? BeneficiaryRelation { get; set; }
        public decimal? BeneficiaryPercentage { get; set; }
    }

    public class CoverageDocumentInfo
    {
        public string MemberID { get; set; } = "";
        public string? PlanType { get; set; }
        public string? PlanName { get; set; }
        public decimal? SumInsured { get; set; }
        public string? DocumentName { get; set; }
        public string? DocumentStatus { get; set; }
        public DateTime? DocumentDate { get; set; }
    }

    public class FinancialHealthInfo
    {
        public string MemberID { get; set; } = "";
        public decimal? LoanAmount { get; set; }
        public decimal? OutstandingAmount { get; set; }
        public string? HealthDeclaration { get; set; }
        public string? MedicalResult { get; set; }
    }

    public class PolicyHistoryItem
    {
        public string MemberID { get; set; } = "";
        public string? TransactionID { get; set; }
        public string? TransactionName { get; set; }
        public DateTime? TransactionDate { get; set; }
        public string? Remarks { get; set; }
    }

    public class LetterItem
    {
        public string MemberID { get; set; } = "";
        public string? LetterType { get; set; }
        public string? LetterName { get; set; }
        public DateTime? LetterDate { get; set; }
        public string? Status { get; set; }
    }

    public class ActivityHistoryItem
    {
        public string MemberID { get; set; } = "";
        public string? ActivityType { get; set; }
        public string? Description { get; set; }
        public DateTime? ActivityDate { get; set; }
        public string? UserID { get; set; }
    }

    public class CertificateDetailResult
    {
        public CertificateHeader? Header { get; set; }
        public CertificateInfo? CertInfo { get; set; }
    }
}