﻿using System.ComponentModel.DataAnnotations;

namespace IClipsLoginAPI.Models;

public class User
{
    public string UserID { get; set; } = "";  // kolom UserID (untuk JWT claims)
    public string UserName { get; set; } = "";  // kolom UserName (untuk login credential)
    public string CompanyID { get; set; } = "";
}

public class Company
{
    public string CompanyID { get; set; } = string.Empty;
    public string CompanyName { get; set; } = string.Empty;
}

public class LoginRequest
{
  
    
        [Required]
        public string UserID { get; set; } = "";   // ← ganti dari Username

     
        [Required]
        public string CompanyID { get; set; } = "";
    
}

public class LoginResponse
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public string Token { get; set; } = string.Empty;
    public string UserID { get; set; } = string.Empty;
    public string CompanyID { get; set; } = string.Empty;
    public string CompanyName { get; set; } = string.Empty;
    public DateTime ExpiresAt { get; set; }
}

public class UserProfile
{
    public string UserID { get; set; } = string.Empty;
    public string CompanyID { get; set; } = string.Empty;
    public string CompanyName { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
}