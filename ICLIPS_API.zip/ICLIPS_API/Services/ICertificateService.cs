﻿using ICLIPS_API.DTOs;

namespace ICLIPS_API.Services;

public interface ICertificateService
{
    Task<PagedResult<CertificateDto>> GetCertificateListAsync(CertificateFilterDto filter);
    Task<CertificateDto?> GetByMemberIdAsync(string memberId, string companyId);
}