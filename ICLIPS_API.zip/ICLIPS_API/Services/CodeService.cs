﻿using Dapper;
using Microsoft.Data.SqlClient;

namespace ICLIPS_API.Services;

public interface ICodeService
{
    Task<List<CodeDto>> GetCodesAsync(string companyId, string fieldName, string codeCategory = "");
}

public class CodeService : ICodeService
{
    private readonly IConfiguration _config;

    public CodeService(IConfiguration config)
    {
        _config = config;
    }

    private SqlConnection Conn()
        => new(_config.GetConnectionString("DefaultConnection"));

    public async Task<List<CodeDto>> GetCodesAsync(string companyId, string fieldName, string codeCategory = "")
    {
        var codeType = MapFieldToCodeType(fieldName);

        using var conn = Conn();

        const string sql = @"
            SELECT '' AS CodeID, '' AS CodeName, 0 AS CodeSequence
            UNION ALL
            SELECT CodeID, CodeName, CodeSequence
            FROM tdcode
            WHERE CompanyID = @CompanyID
              AND CodeType  = @CodeType
              AND Postpone  = 0
              AND (
                    @CodeCategory = ''
                    OR CodeCategory = @CodeCategory
                    OR CodeCategory = '*'
                  )
            ORDER BY CodeSequence, CodeName";

        var result = await conn.QueryAsync<CodeDto>(sql, new
        {
            CompanyID = companyId,
            CodeType = codeType,
            CodeCategory = codeCategory ?? string.Empty
        });

        return result.ToList();
    }

    private static string MapFieldToCodeType(string fieldName)
    {
        if (string.IsNullOrWhiteSpace(fieldName))
            throw new ArgumentException("Field name wajib diisi.", nameof(fieldName));

        return fieldName.Trim().ToLowerInvariant() switch
        {
            "progressstatusname" => "PRGST",
            "certificatestatus" => "CERST",
            "uwstatus" => "UWSTS",
            _ => throw new ArgumentException($"Field '{fieldName}' tidak dikenali.", nameof(fieldName))
        };
    }
}

public class CodeDto
{
    public string CodeID { get; set; } = "";
    public string CodeName { get; set; } = "";
    public int CodeSequence { get; set; }
}