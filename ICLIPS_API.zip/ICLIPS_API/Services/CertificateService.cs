﻿using Dapper;
using ICLIPS_API.DTOs;
using Microsoft.Data.SqlClient;

namespace ICLIPS_API.Services;

public class CertificateService : ICertificateService
{
    private readonly IConfiguration _config;

    public CertificateService(IConfiguration config) => _config = config;

    private SqlConnection Conn()
        => new(_config.GetConnectionString("DefaultConnection"));

    public async Task<PagedResult<CertificateDto>> GetCertificateListAsync(CertificateFilterDto filter)
    {
        // Guard pagination


        if (filter.PageNumber < 1) filter.PageNumber = 1;
        if (filter.PageSize < 1 || filter.PageSize > 200) filter.PageSize = 20;

        using var conn = Conn();

        var p = new DynamicParameters();
        p.Add("@MemberID", filter.MemberID);
        p.Add("@CompanyID", filter.CompanyID);
        p.Add("@PolicyID", filter.PolicyID);
        p.Add("@CertificateID", filter.CertificateID);
        p.Add("@CertificateStatus", filter.CertificateStatus);
        p.Add("@InsuredName", filter.InsuredName);       // ← tambah
        p.Add("@PageNumber", filter.PageNumber);
        p.Add("@PageSize", filter.PageSize);
        p.Add("@SortColumn", filter.SortColumn);
        p.Add("@SortDirection", filter.SortDirection);

        using var multi = await conn.QueryMultipleAsync(
            "dbo.sp_GetCertificateNewList", p,
            commandType: System.Data.CommandType.StoredProcedure);

        var total = await multi.ReadFirstOrDefaultAsync<int>();
        var data = (await multi.ReadAsync<CertificateDto>()).ToList();

        return new PagedResult<CertificateDto>
        {
            Data = data,
            TotalRecords = total,
            PageNumber = filter.PageNumber,
            PageSize = filter.PageSize
        };
    }

    public async Task<CertificateDto?> GetByMemberIdAsync(string memberId, string companyId)
    {
        using var conn = Conn();

        var p = new DynamicParameters();
        p.Add("@MemberID", memberId);
        p.Add("@CompanyID", companyId);
        p.Add("@PageNumber", 1);
        p.Add("@PageSize", 1);

        using var multi = await conn.QueryMultipleAsync(
            "dbo.sp_GetCertificateList", p,
            commandType: System.Data.CommandType.StoredProcedure);

        await multi.ReadFirstOrDefaultAsync<int>(); // skip total
        return await multi.ReadFirstOrDefaultAsync<CertificateDto>();
    }
}