﻿using IClipsLoginAPI.Models;

namespace IClipsLoginAPI.Services;

public interface IAuthService
{
    Task<LoginResponse> LoginAsync(LoginRequest request);
    SessionInfo? GetSession(string token);
    void RemoveSession(string token);
}

public class AuthService : IAuthService
{
    private readonly IUserService _userSvc;
    private readonly ILogger<AuthService> _logger;
    private readonly IConfiguration _config;

    private const string DefaultPassword = "Sunlife1234567891";

    private static readonly Dictionary<string, SessionInfo> _sessions = new();
    private static readonly object _lock = new();

    public AuthService(
        IConfiguration config,
        IUserService userSvc,
        ILogger<AuthService> logger)
    {
        _config = config;
        _userSvc = userSvc;
        _logger = logger;
    }

    public async Task<LoginResponse> LoginAsync(LoginRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.UserID) ||
            string.IsNullOrWhiteSpace(req.CompanyID))
        {
            return Fail("User ID dan Company ID wajib diisi.");
        }

        var userId = req.UserID.Trim().ToUpperInvariant();
        var companyId = req.CompanyID.Trim();

        var user = await _userSvc.ValidateUserAsync(userId, DefaultPassword, companyId);
        if (user == null)
        {
            _logger.LogWarning("Login failed: {UserID}/{CompanyID}", userId, companyId);
            return Fail("User ID atau Company ID salah.");
        }

        var company = await _userSvc.GetCompanyAsync(companyId)
                      ?? new Company
                      {
                          CompanyID = companyId,
                          CompanyName = companyId
                      };

        var token = Guid.NewGuid().ToString("N");
        var expireMin = _config.GetValue<int>("Session:ExpireMinutes", 480);
        var expiresAt = DateTime.UtcNow.AddMinutes(expireMin);

        var session = new SessionInfo
        {
            Token = token,
            UserID = user.UserID,
            CompanyID = user.CompanyID,
            CompanyName = company.CompanyName,
            ExpiresAt = expiresAt
        };

        lock (_lock)
        {
            CleanupExpiredSessions();
            _sessions[token] = session;
        }

        _logger.LogInformation("Login OK: {UserID}/{CompanyID}", user.UserID, user.CompanyID);

        return new LoginResponse
        {
            Success = true,
            Message = "Login berhasil.",
            Token = token,
            UserID = user.UserID,
            CompanyID = user.CompanyID,
            CompanyName = company.CompanyName,
            ExpiresAt = expiresAt
        };
    }

    public SessionInfo? GetSession(string token)
    {
        if (string.IsNullOrWhiteSpace(token))
            return null;

        lock (_lock)
        {
            if (!_sessions.TryGetValue(token, out var session))
                return null;

            if (session.ExpiresAt <= DateTime.UtcNow)
            {
                _sessions.Remove(token);
                return null;
            }

            return session;
        }
    }

    public void RemoveSession(string token)
    {
        if (string.IsNullOrWhiteSpace(token))
            return;

        lock (_lock)
        {
            _sessions.Remove(token);
        }
    }

    private void CleanupExpiredSessions()
    {
        var now = DateTime.UtcNow;

        var expiredTokens = _sessions
            .Where(x => x.Value.ExpiresAt <= now)
            .Select(x => x.Key)
            .ToList();

        foreach (var key in expiredTokens)
        {
            _sessions.Remove(key);
        }
    }

    private static LoginResponse Fail(string msg) => new()
    {
        Success = false,
        Message = msg,
        Token = string.Empty,
        UserID = string.Empty,
        CompanyID = string.Empty,
        CompanyName = string.Empty,
        ExpiresAt = DateTime.MinValue
    };
}

public class SessionInfo
{
    public string Token { get; set; } = "";
    public string UserID { get; set; } = "";
    public string CompanyID { get; set; } = "";
    public string CompanyName { get; set; } = "";
    public DateTime ExpiresAt { get; set; }
}