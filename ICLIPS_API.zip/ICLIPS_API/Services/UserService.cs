﻿using Dapper;
using Microsoft.Data.SqlClient;
using IClipsLoginAPI.Models;

namespace IClipsLoginAPI.Services;

public interface IUserService
{
    Task<User?> GetUserAsync(string username, string companyId);
    Task<User?> ValidateUserAsync(string userID, string password, string companyId);
    Task<Company?> GetCompanyAsync(string companyId);
    Task<List<Company>> GetAllCompaniesAsync();
}

public class UserService : IUserService
{
    private readonly IConfiguration _config;
    private readonly ILogger<UserService> _logger;

    public UserService(IConfiguration config, ILogger<UserService> logger)
    { _config = config; _logger = logger; }

    private SqlConnection Conn()
        => new(_config.GetConnectionString("NDISIS02"));

    // Method lama — tetap dipertahankan jika masih dipakai di tempat lain
    public async Task<User?> GetUserAsync(string username, string companyId)
    {
        try
        {
            using var conn = Conn();
            const string sql = @"
                SELECT TOP 1 UserID, CompanyID
                FROM tuser
                WHERE UserID    = @UserID
                  AND CompanyID = @CompanyID
                  ";

            return await conn.QueryFirstOrDefaultAsync<User>(sql, new
            {
                UserID = username.ToUpper(),
                CompanyID = companyId
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "DB error GetUser [{Username}]", username);
            return null;
        }
    }

    // ← METHOD BARU: validasi username + password + companyID sekaligus
    public async Task<User?> ValidateUserAsync(string userID, string password, string companyId)
    {
        try
        {
            using var conn = Conn();
            const string sql = @"
            SELECT TOP 1 UserID, CompanyID
            FROM [dbo].[tuser]
            WHERE UserID    = @UserID      -- ← ganti dari UserName
             
              AND CompanyID = @CompanyID";

            return await conn.QueryFirstOrDefaultAsync<User>(sql, new
            {
                UserID = userID.ToUpper(),  // ← ganti dari UserName
          
                CompanyID = companyId
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "DB error ValidateUser [{UserID}/{CompanyId}]", userID, companyId);
            return null;
        }
    }
    public async Task<Company?> GetCompanyAsync(string companyId)
    {
        try
        {
            using var conn = Conn();
            return await conn.QueryFirstOrDefaultAsync<Company>(
                "SELECT CompanyID, CompanyName FROM tcompany WHERE CompanyID = @CompanyID",
                new { CompanyID = companyId });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "DB error GetCompany [{CompanyId}]", companyId);
            return null;
        }
    }

    public async Task<List<Company>> GetAllCompaniesAsync()
    {
        try
        {
            using var conn = Conn();
            var result = await conn.QueryAsync<Company>(
                "SELECT CompanyID, CompanyName FROM tcompany ORDER BY CompanyName");
            return result.ToList();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "DB error GetCompanies");
            return new();
        }
    }
}