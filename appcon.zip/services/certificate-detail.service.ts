import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  CertificateDetailResponse, ClientInfo, AgentInfo, ProductPackageOption,
  CoverageDocumentInfo, HealthQuestionInfo, ProductAppliedItem,
  PolicyHistoryItem, LetterItem, ActivityHistoryItem
} from '../models/certificate-detail.model';

@Injectable({ providedIn: 'root' })
export class CertificateDetailService {
  private http = inject(HttpClient);
  private baseUrl = 'https://localhost:7201/api/certificate';

  getDetail(certificateID: string): Observable<CertificateDetailResponse> {
    return this.http.get<CertificateDetailResponse>(`${this.baseUrl}/${certificateID}/detail`);
  }

  getClientInfo(clientID: string): Observable<ClientInfo> {
    return this.http.get<ClientInfo>(`${this.baseUrl}/client/${clientID}`);
  }


  getAgentInfo(memberID: string, companyID: string, policyID: string): Observable<AgentInfo> {
  return this.http.get<AgentInfo>(`${this.baseUrl}/agent`, { params: { memberID, companyID, policyID } });
}

  getProductPackageOptions(companyID: string, productPackageID?: string): Observable<ProductPackageOption[]> {
    const params: any = { companyID };
    if (productPackageID) params.productPackageID = productPackageID;
    return this.http.get<ProductPackageOption[]>(`${this.baseUrl}/product-package`, { params });
  }

  getCoverageDocument(memberID: string, companyID: string, productPackageID: string): Observable<CoverageDocumentInfo[]> {
    return this.http.get<CoverageDocumentInfo[]>(`${this.baseUrl}/${memberID}/coverage-document`, { params: { companyID, productPackageID } });
  }

  getFinancialHealth(memberID: string, companyID: string, productID: string, policyID: string): Observable<HealthQuestionInfo[]> {
    return this.http.get<HealthQuestionInfo[]>(`${this.baseUrl}/${memberID}/financial-health`, { params: { companyID, productID, policyID } });
  }

  getProductApplied(memberID: string): Observable<ProductAppliedItem[]> {
    return this.http.get<ProductAppliedItem[]>(`${this.baseUrl}/${memberID}/policy-history/product-applied`);
  }

  getPolicyHistory(memberID: string): Observable<PolicyHistoryItem[]> {
    return this.http.get<PolicyHistoryItem[]>(`${this.baseUrl}/${memberID}/policy-history`);
  }

  getLetters(memberID: string): Observable<LetterItem[]> {
    return this.http.get<LetterItem[]>(`${this.baseUrl}/${memberID}/letters`);
  }

  getActivityHistory(memberID: string): Observable<ActivityHistoryItem[]> {
    return this.http.get<ActivityHistoryItem[]>(`${this.baseUrl}/${memberID}/activity-history`);
  }
}