declare module 'choices.js' {
  const Choices: any;
  export default Choices;
}