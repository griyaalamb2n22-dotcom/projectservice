// src/app/app.routes.ts
import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { guestGuard } from './core/guards/guest.guard';

export const routes: Routes = [
  {
    path: 'login',
    canActivate: [guestGuard],
    title: 'Login',
    loadComponent: () =>
      import('./pages/login/login.component').then(m => m.LoginComponent)
  },

  {
    path: '',
    canActivate: [authGuard],
    title: 'Dashboard',
    loadComponent: () =>
      import('./layout/dashboard-layout/dashboard-layout.component').then(
        m => m.DashboardLayoutComponent
      ),
    children: [
      {
        path: '',
        title: 'Dashboard',
        loadComponent: () =>
          import('./pages/dashboard/dashboard.component').then(
            m => m.DashboardComponent
          )
      },

      {
        path: 'email',
        title: 'Email',
        loadComponent: () =>
          import('./pages/dashboard/dashboard.component').then(
            m => m.DashboardComponent
          )
      },

      {
        path: 'chat',
        title: 'Chat',
        loadComponent: () =>
          import('./pages/dashboard/dashboard.component').then(
            m => m.DashboardComponent
          )
      },

      {
        path: 'calendar',
        title: 'Calendar',
        loadComponent: () =>
          import('./pages/dashboard/dashboard.component').then(
            m => m.DashboardComponent
          )
      },

      {
        path: 'certificate-list',
        title: 'Certificate List',
        loadComponent: () =>
          import('./pages/certificate-list/certificate-list.component').then(
            m => m.CertificateListComponent
          )
      },
      {
        path: 'new-business',
        title: 'New Certificate',
        loadComponent: () =>
        import('./pages/new-business/new-business.component').then(
         m => m.NewBusinessComponent
    )
},
  {
        path: 'new-client',
        title: 'New Client',
        loadComponent: () =>
        import('./pages/new-client/new-client.component').then(
         m => m.NewClientComponent
    )
},
 {
    path: 'covernote-pdf',
    loadComponent: () =>
      import('./pages/covernote-pdf/covernote-pdf.component').then((m) => m.CovernotePdfComponent)
  },
  {
  path: 'client-extract',
  loadComponent: () =>
    import('./pages/client-extract/client-extract.component').then(m => m.ClientExtractComponent)
},

      {
        path: 'ui/accordion',
        title: 'Accordion',
        loadComponent: () =>
          import('./pages/dashboard/dashboard.component').then(
            m => m.DashboardComponent
          )
      },

      {
  path: 'sweet-alert',
  loadComponent: () =>
    import('./pages/sweet-alert-demo/sweet-alert-demo.component').then(
      (m) => m.SweetAlertDemoComponent
    )
},
{
  path: 'alerts',
  loadComponent: () =>
    import('./pages/alert-demo/alert-demo.component').then(
      (m) => m.AlertDemoComponent
    )
},

      {
        path: 'ui/badges',
        title: 'Badges',
        loadComponent: () =>
          import('./pages/dashboard/dashboard.component').then(
            m => m.DashboardComponent
          )
      },

      {
        path: 'ui/breadcrumbs',
        title: 'Breadcrumbs',
        loadComponent: () =>
          import('./pages/dashboard/dashboard.component').then(
            m => m.DashboardComponent
          )
      },
      {
  path: 'icons',
  title: 'Icons',
  loadComponent: () =>
    import('./pages/icons/icons.component').then(
      m => m.IconsComponent
    )
},
{
  path: 'buttons',
  loadComponent: () =>
    import('./pages/buttons-demo/buttons-demo.component').then(
      (m) => m.ButtonsDemoComponent
    )
}

     
    ]
  },

  {
    path: '**',
    redirectTo: ''
  }
];