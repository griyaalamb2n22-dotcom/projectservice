// src/app/layout/topbar/topbar.component.ts
import { Component, HostListener, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { AppStateService } from '../../core/services/app-state.service';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './topbar.component.html',
  styleUrl: './topbar.component.scss'
})
export class TopbarComponent {
  private readonly authService = inject(AuthService);
  private readonly appStateService = inject(AppStateService);
  private readonly router = inject(Router);

  search = '';
  language = 'English';

  readonly currentUser = this.authService.currentUser;
  readonly dropdownOpen = signal(false);

  readonly displayName = computed(() => this.currentUser()?.fullName ?? 'Administrator');
  readonly initials = computed(() => {
    const name = this.currentUser()?.fullName ?? 'Admin User';
    return name
      .split(' ')
      .map(part => part.charAt(0))
      .join('')
      .slice(0, 2)
      .toUpperCase();
  });

  toggleSidebar(): void {
    this.appStateService.toggleSidebar();
  }

  toggleTheme(): void {
    this.appStateService.toggleDarkMode();
  }

  toggleProfileMenu(): void {
    this.dropdownOpen.update(value => !value);
  }

  closeProfileMenu(): void {
    this.dropdownOpen.set(false);
  }

  logout(): void {
    this.authService.logout();
    this.dropdownOpen.set(false);
    this.router.navigateByUrl('/login');
  }

  @HostListener('document:click')
  onDocumentClick(): void {
    this.closeProfileMenu();
  }
}