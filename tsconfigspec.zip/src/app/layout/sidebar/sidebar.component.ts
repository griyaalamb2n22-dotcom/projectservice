// src/app/layout/sidebar/sidebar.component.ts
import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { MenuItem, MenuSection } from '../../shared/interfaces/menu.interface';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss'
})
export class SidebarComponent {
  readonly collapsed = signal(false);
  private readonly expandedItems = signal<Set<string>>(new Set(['Certificate']));

  readonly menuSections: MenuSection[] = [
    {
      title: 'MAIN',
      items: [{ label: 'Dashboard', icon: 'ri-home-5-line', route: '/' }]
    },
    {
      title: 'Policy & Certificate',
      items: [
        {
          label: 'Certificate',
          icon: 'ri-list-check',
          children: [
            { label: 'Certificate List', route: '/certificate-list' },
            { label: 'New Business', route: '/new-business' }
          ]
        },
        { label: 'Underwriting', icon: 'ri-pass-valid-line', route: '/chat' },
        { label: 'Policy Admin', icon: 'ri-folder-user-line', route: '/calendar' }
      ]
    },
    {
      title: 'COMPONENTS',
      items: [
        {
          label: 'UI Kit',
          icon: 'ri-pencil-ruler-2-line',
          children: [
            { label: 'Accordion', route: '/ui/accordion' },
            { label: 'Alerts', route: '/alerts' },
            { label: 'Badges', route: '/ui/badges' },
            { label: 'Buttons', route: '/buttons' }
          ]
        },
        {
          label: 'Advanced UI',
          icon: 'ri-anchor-line',
          children: [
            { label: 'Sweet Alert', route: '/sweet-alert' },
            { label: 'Scroll Ranges', route: '/advanced/scroll-ranges' }
          ]
        },
        {
          label: 'Forms',
          icon: 'ri-file-list-3-line',
          children: [
            { label: 'AddNew Client', route: '/new-client' },
            { label: 'Cetak PDF', route: '/covernote-pdf' },
             { label: 'Download Excel', route: '/client-extract' }
          ]
        },
        
        {
          label: 'Tables',
          icon: 'ri-layout-grid-line',
          children: [
            { label: 'Basic Tables', route: '/tables/basic' },
            { label: 'Data Tables', route: '/tables/data' }
          ]
        },
        { label: 'Icons', icon: 'ri-emotion-line', route: '/icons' }
      ]
    },
    {
      title: 'PAGES',
      items: [{ label: 'Sample Page', icon: 'ri-file-copy-line', route: '/pages/sample' }]
    }
  ];

  toggleSidebar(): void {
    this.collapsed.update(value => !value);
  }

  isExpanded(item: MenuItem): boolean {
    return this.expandedItems().has(item.label);
  }

  toggle(item: MenuItem): void {
    if (this.collapsed()) {
      return;
    }

    const next = new Set(this.expandedItems());
    next.has(item.label) ? next.delete(item.label) : next.add(item.label);
    this.expandedItems.set(next);
  }
}