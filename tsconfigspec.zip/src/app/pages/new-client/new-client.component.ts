// src/app/pages/new-client/new-client.component.ts
import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, OnDestroy } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import flatpickr from 'flatpickr';
import type { Instance as FlatpickrInstance } from 'flatpickr/dist/types/instance';
import Choices from 'choices.js';

@Component({
  selector: 'app-new-client',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './new-client.component.html',
  styleUrls: ['./new-client.component.scss']
})
export class NewClientComponent implements AfterViewInit, OnDestroy {
  submitted = false;
  saveMessage = '';

  customerProfileForm: FormGroup;

  agamaOptions = [
    { label: 'Islam', value: 'Islam' },
    { label: 'Kristen', value: 'Kristen' },
    { label: 'Katolik', value: 'Katolik' },
    { label: 'Hindu', value: 'Hindu' },
    { label: 'Buddha', value: 'Buddha' },
    { label: 'Konghucu', value: 'Konghucu' }
  ];

  statusNasabahOptions = [
    { label: 'Aktif', value: 'Aktif' },
    { label: 'Tidak Aktif', value: 'Tidak Aktif' },
    { label: 'Prioritas', value: 'Prioritas' }
  ];

private statusChoices: any;
private agamaChoices: any;
  private tanggalLahirPicker?: FlatpickrInstance;

  constructor(private fb: FormBuilder) {
    this.customerProfileForm = this.fb.group({
      namaNasabah: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      noHp: ['', [Validators.required, Validators.pattern(/^[0-9]{10,15}$/)]],
      tanggalLahir: ['', Validators.required],
      jenisKelamin: ['', Validators.required],
      statusNasabah: ['', Validators.required],
      agama: ['', Validators.required],
      hobi: this.fb.group({
        membaca: [false],
        olahraga: [false],
        musik: [false]
      }),
      setujuData: [false, Validators.requiredTrue]
    });
  }

  ngAfterViewInit(): void {
    this.initDatePicker();
    this.initChoices();
  }

  ngOnDestroy(): void {
    this.statusChoices?.destroy();
    this.agamaChoices?.destroy();
    this.tanggalLahirPicker?.destroy();
  }

  get f() {
    return this.customerProfileForm.controls;
  }

  private initDatePicker(): void {
    const element = document.getElementById('tanggalLahir') as HTMLInputElement | null;

    if (!element) {
      return;
    }

    this.tanggalLahirPicker = flatpickr(element, {
      dateFormat: 'Y-m-d',
      allowInput: true,
      disableMobile: true,
      onChange: (_selectedDates, dateStr) => {
        this.customerProfileForm.patchValue({
          tanggalLahir: dateStr
        });
      }
    });
  }

  private initChoices(): void {
    const statusElement = document.getElementById('statusNasabah') as HTMLSelectElement | null;
    const agamaElement = document.getElementById('agama') as HTMLSelectElement | null;

    if (statusElement) {
      this.statusChoices = new Choices(statusElement, {
        searchEnabled: true,
        searchPlaceholderValue: 'Cari status...',
        itemSelectText: '',
        shouldSort: false,
        allowHTML: false,
        placeholder: true,
        placeholderValue: 'Pilih status',
        noResultsText: 'Data tidak ditemukan',
        noChoicesText: 'Tidak ada pilihan'
      });

      statusElement.addEventListener('change', (event: Event) => {
        const target = event.target as HTMLSelectElement;
        this.customerProfileForm.patchValue({
          statusNasabah: target.value
        });
      });
    }

    if (agamaElement) {
      this.agamaChoices = new Choices(agamaElement, {
        searchEnabled: true,
        searchPlaceholderValue: 'Cari agama...',
        itemSelectText: '',
        shouldSort: false,
        allowHTML: false,
        placeholder: true,
        placeholderValue: 'Pilih agama',
        noResultsText: 'Data tidak ditemukan',
        noChoicesText: 'Tidak ada pilihan'
      });

      agamaElement.addEventListener('change', (event: Event) => {
        const target = event.target as HTMLSelectElement;
        this.customerProfileForm.patchValue({
          agama: target.value
        });
      });
    }
  }

  onSave(): void {
    this.submitted = true;
    this.saveMessage = '';

    if (this.customerProfileForm.invalid) {
      this.customerProfileForm.markAllAsTouched();
      return;
    }

    console.log('Data profil nasabah:', this.customerProfileForm.value);
    this.saveMessage = 'Data sudah di simpan';

    this.customerProfileForm.reset({
      namaNasabah: '',
      email: '',
      noHp: '',
      tanggalLahir: '',
      jenisKelamin: '',
      statusNasabah: '',
      agama: '',
      hobi: {
        membaca: false,
        olahraga: false,
        musik: false
      },
      setujuData: false
    });

    this.tanggalLahirPicker?.clear();
    this.statusChoices?.setChoiceByValue('');
    this.agamaChoices?.setChoiceByValue('');

    this.submitted = false;
  }
}