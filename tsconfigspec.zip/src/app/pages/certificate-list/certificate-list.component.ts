// src/app/pages/certificate-list/certificate-list.component.ts
// src/app/pages/certificate-list/certificate-list.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

interface CertificateRow {
  policyName: string;
  certificateNo: string;
  insuredId: string;
  insuredName: string;
  progressStatus: string;
  statusKey: 'issued' | 'underwritten' | 'pending' | 'surrender' | 'inforce' | 'progress';
}

@Component({
  selector: 'app-certificate-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './certificate-list.component.html',
  styleUrl: './certificate-list.component.scss'
})
export class CertificateListComponent {
  certificateSearch = '';
  taskMenuOpen = false;
  currentPage = 1;
  pageSize = 10;

  certificateList: CertificateRow[] = [
    {
      policyName: '889 - PT BANK CIMB NIAGA TBK Mortgage Syariah',
      certificateNo: '889000042553',
      insuredId: 'CLJ0000475711',
      insuredName: 'TEST SPIN OFF LIMA',
      progressStatus: 'NB To be issued',
      statusKey: 'issued'
    },
    {
      policyName: '889 - PT BANK CIMB NIAGA TBK Mortgage Syariah',
      certificateNo: '889000045053',
      insuredId: 'CLJ0000475783',
      insuredName: 'TEST SPIN OFF DUA',
      progressStatus: 'NB To be underwritten',
      statusKey: 'underwritten'
    },
    {
      policyName: '999 - PT BANK CIMB NIAGA TBK Mortgage',
      certificateNo: '999000404375',
      insuredId: 'CLJ0000475790',
      insuredName: 'TEST SPIN CONV EMPAT',
      progressStatus: 'NB To be issued',
      statusKey: 'issued'
    },
    {
      policyName: '999 - PT BANK CIMB NIAGA TBK Mortgage',
      certificateNo: '999000404374',
      insuredId: 'CLJ0000475779',
      insuredName: 'TEST SPIN CONV TIGA',
      progressStatus: 'NB To be issued - awaiting payment',
      statusKey: 'pending'
    },
    {
      policyName: '889 - PT BANK CIMB NIAGA TBK Mortgage Syariah',
      certificateNo: '889000045051',
      insuredId: 'CLJ0000475778',
      insuredName: 'TEST SPIN SYA SATU',
      progressStatus: 'Surrender',
      statusKey: 'surrender'
    },
    {
      policyName: '7962 - PT BANK CIMB NIAGA TBK Mortgage Syariah',
      certificateNo: '796200002213',
      insuredId: 'CLJ000055487',
      insuredName: 'REZA PRADITYA SANDY',
      progressStatus: 'NB To be issued',
      statusKey: 'issued'
    },
    {
      policyName: '7962 - PT BANK CIMB NIAGA TBK Mortgage Syariah',
      certificateNo: '796200002211',
      insuredId: 'CLJ000057205',
      insuredName: 'JESSICA FALINE',
      progressStatus: 'In force',
      statusKey: 'inforce'
    },
    {
      policyName: '778 - PT BANK MUAMALAT INDONESIA TBK Mortgage BNI Syariah',
      certificateNo: '778000000054',
      insuredId: 'CLJ000221844',
      insuredName: 'BEN ARTHUR LARSON',
      progressStatus: 'NB in progress',
      statusKey: 'progress'
    },
    {
      policyName: '805 - PT BANK CIMB NIAGA TBK Mortgage Syariah',
      certificateNo: '805000014890',
      insuredId: 'CLJ000211813',
      insuredName: 'DEWI MARTHA NAPITUPULU',
      progressStatus: 'NB to be underwritten',
      statusKey: 'underwritten'
    },
    {
      policyName: '806 - OCBC Sharia Mortgage Syariah',
      certificateNo: '778000000079',
      insuredId: 'CLJ000067196',
      insuredName: 'ACTIVIANA MUSLIM',
      progressStatus: 'NB in progress',
      statusKey: 'progress'
    },
    {
      policyName: '778 - PT BANK MUAMALAT INDONESIA TBK Mortgage BNI Syariah',
      certificateNo: '778000000080',
      insuredId: 'CLJ000221844',
      insuredName: 'BEN ARTHUR LARSON',
      progressStatus: 'In force',
      statusKey: 'inforce'
    }
  ];

  get filteredCertificates(): CertificateRow[] {
    const keyword = this.certificateSearch.trim().toLowerCase();

    if (!keyword) {
      return this.certificateList;
    }

    return this.certificateList.filter((item) =>
      item.policyName.toLowerCase().includes(keyword) ||
      item.certificateNo.toLowerCase().includes(keyword) ||
      item.insuredId.toLowerCase().includes(keyword) ||
      item.insuredName.toLowerCase().includes(keyword) ||
      item.progressStatus.toLowerCase().includes(keyword)
    );
  }

  get pagedCertificates(): CertificateRow[] {
    const start = (this.currentPage - 1) * this.pageSize;
    const end = start + this.pageSize;
    return this.filteredCertificates.slice(start, end);
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.filteredCertificates.length / this.pageSize));
  }

  get pageNumbers(): number[] {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  toggleTaskMenu(): void {
    this.taskMenuOpen = !this.taskMenuOpen;
  }

  closeTaskMenu(): void {
    this.taskMenuOpen = false;
  }

  refresh(): void {
    console.log('Refresh certificate list');
  }

  onTaskClick(action: string): void {
    console.log('Task selected:', action);
    this.closeTaskMenu();
  }

  goToPage(page: number): void {
    if (page < 1 || page > this.totalPages) {
      return;
    }
    this.currentPage = page;
  }

  prevPage(): void {
    this.goToPage(this.currentPage - 1);
  }

  nextPage(): void {
    this.goToPage(this.currentPage + 1);
  }
}