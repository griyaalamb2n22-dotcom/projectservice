// src/app/pages/new-business/new-business.component.ts
import { Component, ElementRef, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface PolicyLookupItem {
  policyNo: string;
  policyOwner: string;
  productType: string;
}

@Component({
  selector: 'app-new-business',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './new-business.component.html',
  styleUrl: './new-business.component.scss'
})
export class NewBusinessComponent {
  policyNo = '';
  policyKeyword = '';
  ownerName = '';
  productType = '';

  insuredName = '';
  insuredDob = '';
  insuredSex = '';
  insuredId = '';
  insuredAlternateId = '';

  insuredAsDebitur = false;
  debiturName = '';
  debiturDob = '';
  debiturSex = '';
  debiturId = '';
  debiturAlternateId = '';

  agentId = '';
  agentName = '';
  branchName = '';
  mainBranchName = '';
  areaName = '';
  creditName = '';

  policyLookupOpen = false;

  readonly policies: PolicyLookupItem[] = [
    {
      policyNo: '001',
      policyOwner: 'PT BANK CIMB NIAGA TBK',
      productType: 'Asuransi Jiwa Kumpulan Pendidikan Xtra'
    },
    {
      policyNo: '004',
      policyOwner: 'PT BANK CIMB NIAGA TBK',
      productType: 'SJLT Credit Protection Plus'
    },
    {
      policyNo: '005',
      policyOwner: 'PT BPR NAGA ARTHA FINANCE',
      productType: 'SJLT Credit Protection Plus'
    },
    {
      policyNo: '010',
      policyOwner: 'PT BANK INTERUSA ARTHA FINANCE',
      productType: 'Personal Loan'
    },
    {
      policyNo: '011',
      policyOwner: 'Cibank',
      productType: 'Life Protection'
    },
    {
      policyNo: '012',
      policyOwner: 'PT BANK CIMB NIAGA TBK',
      productType: 'Personal Loan Syariah'
    }
  ];

  filteredPolicies: PolicyLookupItem[] = [...this.policies];

  constructor(private elementRef: ElementRef) {}

  @HostListener('document:click', ['$event.target'])
  onDocumentClick(target: HTMLElement): void {
    const clickedInside = this.elementRef.nativeElement.contains(target);
    if (!clickedInside) {
      this.policyLookupOpen = false;
    }
  }

  goBack(): void {
    history.back();
  }

  next(): void {
    console.log('Next clicked', {
      policyNo: this.policyNo,
      ownerName: this.ownerName,
      productType: this.productType
    });
  }

  cancel(): void {
    history.back();
  }

  openPolicyLookup(): void {
    this.policyLookupOpen = true;
    this.filterPolicies();
  }

  togglePolicyLookup(): void {
    this.policyLookupOpen = !this.policyLookupOpen;
    if (this.policyLookupOpen) {
      this.filterPolicies();
    }
  }

  filterPolicies(): void {
    const keyword = this.policyKeyword.trim().toLowerCase();

    if (!keyword) {
      this.filteredPolicies = [...this.policies];
      return;
    }

    this.filteredPolicies = this.policies.filter(item =>
      item.policyNo.toLowerCase().includes(keyword) ||
      item.policyOwner.toLowerCase().includes(keyword) ||
      item.productType.toLowerCase().includes(keyword)
    );
  }

  selectPolicy(item: PolicyLookupItem): void {
    this.policyNo = item.policyNo;
    this.policyKeyword = item.policyNo;
    this.ownerName = item.policyOwner;
    this.productType = item.productType;
    this.policyLookupOpen = false;
  }

  findInsured(): void {
    console.log('Find insured client');
  }

  findDebitur(): void {
    console.log('Find debitur client');
  }

  viewInsuredDetail(): void {
    console.log('View insured detail');
  }

  viewDebiturDetail(): void {
    console.log('View debitur detail');
  }
}