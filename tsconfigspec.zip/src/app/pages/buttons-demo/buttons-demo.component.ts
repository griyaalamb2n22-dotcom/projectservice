import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-buttons-demo',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './buttons-demo.component.html',
  styleUrls: ['./buttons-demo.component.scss']
})
export class ButtonsDemoComponent {
  onClick(label: string): void {
    console.log(`${label} clicked`);
  }
}