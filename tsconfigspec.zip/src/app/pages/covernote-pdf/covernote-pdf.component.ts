import { CommonModule, DatePipe } from '@angular/common';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-covernote-pdf',
  standalone: true,
  imports: [CommonModule, FormsModule, DatePipe],
  templateUrl: './covernote-pdf.component.html',
  styleUrls: ['./covernote-pdf.component.scss']
})
export class CovernotePdfComponent {
  @ViewChild('pdfContent', { static: false }) pdfContent!: ElementRef<HTMLDivElement>;

  form = {
    nomor: '001/CN/VII/2026',
    tanggal: new Date().toISOString().split('T')[0],
    namaNasabah: 'Budi Santoso',
    alamat: 'Jl. Melati No. 10, Jakarta',
    nomorPolis: 'POL-2026-0001',
    produk: 'Asuransi Jiwa',
    premi: 'Rp 5.000.000',
    keterangan:
      'Dengan ini diterangkan bahwa pengajuan asuransi atas nama tersebut di atas sedang dalam proses administrasi dan underwriting. Selama masa covernote ini, perlindungan sementara berlaku sesuai syarat dan ketentuan perusahaan.',
    penandatangan: 'Andi Saputra',
    jabatan: 'Kepala Operasional'
  };

  async downloadPdf(): Promise<void> {
    const element = this.pdfContent?.nativeElement;
    if (!element) return;

    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      backgroundColor: '#ffffff'
    });

    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pageWidth = 210;
    const pageHeight = 297;
    const margin = 10;
    const imgWidth = pageWidth - margin * 2;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = margin;

    pdf.addImage(imgData, 'PNG', margin, position, imgWidth, imgHeight, '', 'FAST');
    heightLeft -= pageHeight - margin * 2;

    while (heightLeft > 0) {
      position = heightLeft - imgHeight + margin;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', margin, position, imgWidth, imgHeight, '', 'FAST');
      heightLeft -= pageHeight - margin * 2;
    }

    pdf.save(`covernote-${this.form.nomor.replace(/[^a-zA-Z0-9]/g, '-')}.pdf`);
  }

  printWindow(): void {
    window.print();
  }
}