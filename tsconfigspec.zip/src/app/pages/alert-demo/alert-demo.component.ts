import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

type AlertType = 'success' | 'danger' | 'warning' | 'info';

interface AlertItem {
  type: AlertType;
  title: string;
  message: string;
  visible: boolean;
}

@Component({
  selector: 'app-alert-demo',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './alert-demo.component.html',
  styleUrls: ['./alert-demo.component.scss']
})
export class AlertDemoComponent {
  alerts: AlertItem[] = [
    {
      type: 'success',
      title: 'Success!',
      message: 'Data berhasil disimpan ke sistem.',
      visible: true
    },
    {
      type: 'danger',
      title: 'Error!',
      message: 'Terjadi kesalahan saat memproses data.',
      visible: true
    },
    {
      type: 'warning',
      title: 'Warning!',
      message: 'Periksa kembali data sebelum melanjutkan.',
      visible: true
    },
    {
      type: 'info',
      title: 'Info!',
      message: 'Informasi terbaru telah tersedia.',
      visible: true
    }
  ];

  closeAlert(index: number): void {
    this.alerts[index].visible = false;
  }

  resetAlerts(): void {
    this.alerts = this.alerts.map(alert => ({
      ...alert,
      visible: true
    }));
  }
}