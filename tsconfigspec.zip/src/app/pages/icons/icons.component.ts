// src/app/pages/icons/icons.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface IconItem {
  name: string;
  className: string;
  category: string;
  popularity: number;
}

@Component({
  selector: 'app-icons',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './icons.component.html',
  styleUrl: './icons.component.scss'
})
export class IconsComponent {
  search = '';
  sortBy: 'popularity' | 'name' = 'popularity';

  readonly icons: IconItem[] = [
    { name: 'Close', className: 'ri-close-line', category: 'action', popularity: 99 },
    { name: 'Check', className: 'ri-check-line', category: 'action', popularity: 98 },
    { name: 'Search', className: 'ri-search-line', category: 'action', popularity: 100 },
    { name: 'Arrow Down', className: 'ri-arrow-down-s-line', category: 'arrow', popularity: 95 },
    { name: 'Add', className: 'ri-add-line', category: 'action', popularity: 96 },
    { name: 'Arrow Right', className: 'ri-arrow-right-s-line', category: 'arrow', popularity: 94 },
    { name: 'Information', className: 'ri-information-line', category: 'status', popularity: 90 },
    { name: 'User', className: 'ri-user-line', category: 'user', popularity: 91 },
    { name: 'Home', className: 'ri-home-4-line', category: 'navigation', popularity: 96 },
    { name: 'Menu', className: 'ri-menu-line', category: 'navigation', popularity: 93 },
    { name: 'Eye', className: 'ri-eye-line', category: 'action', popularity: 92 },
    { name: 'Checkbox Circle', className: 'ri-checkbox-circle-line', category: 'status', popularity: 88 },
    { name: 'Map Pin', className: 'ri-map-pin-line', category: 'location', popularity: 86 },
    { name: 'Mail', className: 'ri-mail-line', category: 'communication', popularity: 94 },

    { name: 'Settings', className: 'ri-settings-3-line', category: 'system', popularity: 89 },
    { name: 'Alert', className: 'ri-error-warning-line', category: 'status', popularity: 87 },
    { name: 'Group', className: 'ri-group-line', category: 'user', popularity: 84 },
    { name: 'Star', className: 'ri-star-line', category: 'rating', popularity: 90 },
    { name: 'Arrow Left', className: 'ri-arrow-left-s-line', category: 'arrow', popularity: 95 },
    { name: 'Delete Bin', className: 'ri-delete-bin-line', category: 'action', popularity: 89 },
    { name: 'Edit', className: 'ri-pencil-line', category: 'action', popularity: 93 },
    { name: 'Magic', className: 'ri-magic-line', category: 'action', popularity: 77 },
    { name: 'Close Circle', className: 'ri-close-circle-line', category: 'status', popularity: 83 },
    { name: 'File Text', className: 'ri-file-text-line', category: 'file', popularity: 80 },
    { name: 'Login Box', className: 'ri-login-box-line', category: 'navigation', popularity: 85 },
    { name: 'Calendar', className: 'ri-calendar-line', category: 'date', popularity: 92 },
    { name: 'Download', className: 'ri-download-line', category: 'action', popularity: 94 },
    { name: 'Edit Box', className: 'ri-edit-box-line', category: 'action', popularity: 82 },

    { name: 'More', className: 'ri-more-2-line', category: 'action', popularity: 88 },
    { name: 'Refresh', className: 'ri-refresh-line', category: 'action', popularity: 91 },
    { name: 'Briefcase', className: 'ri-briefcase-line', category: 'business', popularity: 79 },
    { name: 'Phone', className: 'ri-phone-line', category: 'communication', popularity: 84 },
    { name: 'Error Warning', className: 'ri-error-warning-line', category: 'status', popularity: 90 },
    { name: 'Heart', className: 'ri-heart-line', category: 'reaction', popularity: 89 },
    { name: 'Loader', className: 'ri-loader-4-line', category: 'system', popularity: 81 },
    { name: 'More Fill', className: 'ri-more-fill', category: 'action', popularity: 74 },
    { name: 'Task', className: 'ri-task-line', category: 'status', popularity: 82 },
    { name: 'Time', className: 'ri-time-line', category: 'date', popularity: 83 },
    { name: 'Shield', className: 'ri-shield-line', category: 'security', popularity: 84 },
    { name: 'Send Plane', className: 'ri-send-plane-line', category: 'communication', popularity: 78 },
    { name: 'Shopping Cart', className: 'ri-shopping-cart-line', category: 'commerce', popularity: 79 },
    { name: 'Play', className: 'ri-play-line', category: 'media', popularity: 88 },

    { name: 'Notification', className: 'ri-notification-3-line', category: 'status', popularity: 87 },
    { name: 'Global', className: 'ri-global-line', category: 'location', popularity: 82 },
    { name: 'Apps', className: 'ri-apps-2-line', category: 'navigation', popularity: 83 },
    { name: 'Arrow Right Long', className: 'ri-arrow-right-line', category: 'arrow', popularity: 85 },
    { name: 'Add Circle', className: 'ri-add-circle-line', category: 'action', popularity: 82 },
    { name: 'Question', className: 'ri-question-line', category: 'status', popularity: 74 },
    { name: 'User 3', className: 'ri-user-3-line', category: 'user', popularity: 81 },
    { name: 'Flashlight', className: 'ri-flashlight-line', category: 'utility', popularity: 72 },
    { name: 'Calendar Event', className: 'ri-calendar-event-line', category: 'date', popularity: 79 },
    { name: 'Building', className: 'ri-building-line', category: 'business', popularity: 75 },
    { name: 'Lock', className: 'ri-lock-line', category: 'security', popularity: 92 },
    { name: 'External Link', className: 'ri-external-link-line', category: 'navigation', popularity: 80 },
    { name: 'Medal', className: 'ri-medal-line', category: 'achievement', popularity: 71 },
    { name: 'History', className: 'ri-history-line', category: 'action', popularity: 77 },

    { name: 'Image', className: 'ri-image-line', category: 'media', popularity: 82 },
    { name: 'List Check', className: 'ri-list-check-3', category: 'list', popularity: 81 },
    { name: 'Arrow Up Right', className: 'ri-arrow-right-up-line', category: 'arrow', popularity: 76 },
    { name: 'Link', className: 'ri-link', category: 'action', popularity: 80 },
    { name: 'User Search', className: 'ri-user-search-line', category: 'user', popularity: 73 },
    { name: 'Message 2', className: 'ri-message-2-line', category: 'communication', popularity: 89 },
    { name: 'Repeat', className: 'ri-repeat-line', category: 'action', popularity: 78 },
    { name: 'Share', className: 'ri-share-forward-line', category: 'action', popularity: 88 },
    { name: 'Bookmark', className: 'ri-bookmark-line', category: 'action', popularity: 83 },
    { name: 'Filter', className: 'ri-filter-3-line', category: 'action', popularity: 92 },
    { name: 'Pulse', className: 'ri-pulse-line', category: 'health', popularity: 69 },
    { name: 'Sliders', className: 'ri-equalizer-line', category: 'settings', popularity: 76 },
    { name: 'Save', className: 'ri-save-line', category: 'file', popularity: 95 }
  ];

  get filteredIcons(): IconItem[] {
    const keyword = this.search.trim().toLowerCase();

    let results = this.icons.filter(icon =>
      !keyword ||
      icon.name.toLowerCase().includes(keyword) ||
      icon.className.toLowerCase().includes(keyword) ||
      icon.category.toLowerCase().includes(keyword)
    );

    results = [...results].sort((a, b) => {
      if (this.sortBy === 'name') {
        return a.name.localeCompare(b.name);
      }

      return b.popularity - a.popularity;
    });

    return results;
  }

  trackByIcon(_: number, item: IconItem): string {
    return item.className;
  }
}