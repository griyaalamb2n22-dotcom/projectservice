import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import * as XLSX from 'xlsx';

interface ClientItem {
  clientCode: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  city: string;
  isActive: boolean;
  createdDate: string;
}

@Component({
  selector: 'app-client-extract',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './client-extract.component.html',
  styleUrls: ['./client-extract.component.scss']
})
export class ClientExtractComponent {
  clients: ClientItem[] = [
    {
      clientCode: 'CL001',
      
      firstName: 'Budi',
      lastName: 'Santoso',
      email: 'budi@mail.com',
      phone: '081234567890',
      city: 'Jakarta',
      isActive: true,
      createdDate: '2026-07-01'
    },
    {
      clientCode: 'CL002',
      firstName: 'Siti',
      lastName: 'Aminah',
      email: 'siti@mail.com',
      phone: '081298765432',
      city: 'Bandung',
      isActive: false,
      createdDate: '2026-07-03'
    },
    {
      clientCode: 'CL003',
      firstName: 'Andi',
      lastName: 'Wijaya',
      email: 'andi@mail.com',
      phone: '081277788899',
      city: 'Surabaya',
      isActive: true,
      createdDate: '2026-07-05'
    }
  ];
get activeClientCount(): number {
  return this.clients.filter(item => item.isActive).length;
}

get inactiveClientCount(): number {
  return this.clients.filter(item => !item.isActive).length;
}
  exportToExcel(): void {
    const exportDate = new Date().toLocaleString('id-ID');

    const exportData = this.clients.map((item, index) => ({
      No: index + 1,
      'Kode Client': item.clientCode,
      'Nama Lengkap': `${item.firstName} ${item.lastName}`,
      Email: item.email,
      'No HP': item.phone,
      Kota: item.city,
      'Status Client': item.isActive ? 'Aktif' : 'Non Aktif',
      'Tanggal Dibuat': item.createdDate,
      'Tanggal Export': exportDate,
      Catatan: '',
      Approval: '',
      Keterangan: ''
    }));

    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(exportData, {
      header: [
        'No',
        'Kode Client',
        'Nama Lengkap',
        'Email',
        'No HP',
        'Kota',
        'Status Client',
        'Tanggal Dibuat',
        'Tanggal Export',
        'Catatan',
        'Approval',
        'Keterangan'
      ]
    });

    worksheet['!cols'] = [
      { wch: 8 },
      { wch: 15 },
      { wch: 24 },
      { wch: 28 },
      { wch: 18 },
      { wch: 18 },
      { wch: 16 },
      { wch: 18 },
      { wch: 22 },
      { wch: 20 },
      { wch: 16 },
      { wch: 24 }
    ];

    const workbook: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Data Client');
    XLSX.writeFile(workbook, `extract-client-${new Date().getTime()}.xlsx`);
  }
}