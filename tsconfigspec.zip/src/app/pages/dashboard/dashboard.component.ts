// src/app/pages/dashboard/dashboard.component.ts
import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardService } from '../../core/services/dashboard.service';
import { DashboardStat, RevenuePoint } from '../../core/models/dashboard.model';
import { StatCardComponent } from '../../shared/components/stat-card/stat-card.component';


type RevenueRange = 'Today' | 'Week' | 'Month' | 'Year';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, StatCardComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss'
})
export class DashboardComponent {
  private readonly dashboardService = inject(DashboardService);

  readonly ranges: RevenueRange[] = ['Today', 'Week', 'Month', 'Year'];
  readonly selectedRange = signal<RevenueRange>('Month');
  readonly selectedDate = signal('2026-07-05');

  stats: DashboardStat[] = [];
  revenueData: RevenuePoint[] = [];

  constructor() {
    this.loadData();
  }

  private loadData(): void {
    this.dashboardService.getStats().subscribe(data => {
      this.stats = data;
    });

    this.dashboardService.getRevenueSeries().subscribe(data => {
      this.revenueData = data;
    });
  }

  setRange(range: RevenueRange): void {
    this.selectedRange.set(range);
  }

  trackByLabel(_: number, item: RevenuePoint): string {
    return item.label;
  }

  getBarLeft(index: number): number {
    if (!this.revenueData.length) {
      return 0;
    }

    return (100 / this.revenueData.length) * (index + 0.5);
  }
}