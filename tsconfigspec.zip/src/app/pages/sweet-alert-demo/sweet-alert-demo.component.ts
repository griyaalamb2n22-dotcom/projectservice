import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { SweetAlert2Module } from '@sweetalert2/ngx-sweetalert2';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-sweet-alert-demo',
  standalone: true,
  imports: [CommonModule, SweetAlert2Module],
  templateUrl: './sweet-alert-demo.component.html',
  styleUrls: ['./sweet-alert-demo.component.scss']
})
export class SweetAlertDemoComponent {
  showBasicAlert(): void {
    Swal.fire('Good job!', 'You clicked the button!', 'success');
  }

  showTitleTextAlert(): void {
    Swal.fire({
      title: 'Informasi',
      text: 'Ini adalah alert dengan title dan text di bawahnya.',
      icon: 'info',
      confirmButtonText: 'OK'
    });
  }

  showMixinAlert(): void {
    const toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true
    });

    toast.fire({
      icon: 'success',
      title: 'Data berhasil diproses'
    });
  }

  showCustomHtmlAlert(): void {
    Swal.fire({
      title: 'Custom HTML',
      html: `
        <div style="text-align:left">
          <p><b>Nama:</b> Budi Santoso</p>
          <p><b>Status:</b> Aktif</p>
          <p><b>Keterangan:</b> Data berhasil disimpan.</p>
        </div>
      `,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Simpan',
      cancelButtonText: 'Batal'
    });
  }

  showCustomPositionAlert(): void {
    Swal.fire({
      position: 'top-right',
      icon: 'success',
      title: 'Alert tampil di kanan atas',
      showConfirmButton: false,
      timer: 2000
    });
  }

  showAutoCloseAlert(): void {
    let timerInterval: any;

    Swal.fire({
      title: 'Auto close alert!',
      html: 'Alert ini akan tertutup dalam <b></b> milliseconds.',
      timer: 2500,
      timerProgressBar: true,
      didOpen: () => {
        Swal.showLoading();
        const popup = Swal.getPopup();
        const b = popup?.querySelector('b');

        timerInterval = setInterval(() => {
          if (b) {
            b.textContent = `${Swal.getTimerLeft()}`;
          }
        }, 100);
      },
      willClose: () => {
        clearInterval(timerInterval);
      }
    });
  }
}