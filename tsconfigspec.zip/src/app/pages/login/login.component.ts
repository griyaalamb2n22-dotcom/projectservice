// src/app/pages/login/login.component.ts
import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { finalize } from 'rxjs';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})

export class LoginComponent {
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);

  username = 'admin';
  password = 'admin123';
  rememberMe = true;
  company = 'Sunlife Indonesia';

companies: string[] = [
  'Sunlife Indonesia'
];
  readonly loading = signal(false);
  readonly errorMessage = signal('');

  submit(): void {
    if (!this.username.trim() || !this.password.trim()) {
      this.errorMessage.set('Username dan password wajib diisi.');
      return;
    }

    this.loading.set(true);
    this.errorMessage.set('');

    this.authService.login({
      username: this.username,
      password: this.password,
      rememberMe: this.rememberMe
    }).pipe(
      finalize(() => this.loading.set(false))
    ).subscribe({
      next: () => {
        const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl') || '/';
        this.router.navigateByUrl(returnUrl);
      },
      error: () => {
        this.errorMessage.set('Login gagal. Silakan coba lagi.');
      }
    });
  }
}