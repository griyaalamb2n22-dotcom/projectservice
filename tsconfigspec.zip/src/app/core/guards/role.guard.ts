// src/app/core/guards/role.guard.ts
import { inject } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const roleGuard: CanActivateFn = (route: ActivatedRouteSnapshot) => {
  const authService = inject(AuthService);
  const router = inject(Router);
  const expectedRole = route.data['role'] as string;

  if (!authService.isAuthenticated()) {
    return router.createUrlTree(['/login']);
  }

  if (expectedRole && authService.hasRole(expectedRole)) {
    return true;
  }

  return router.createUrlTree(['/']);
};