// src/app/core/models/user.model.ts
export interface UserProfile {
  id: number;
  username: string;
  fullName: string;
  email: string;
  phone?: string;
  language?: string;
  role: string;
  avatar?: string;
  address?: string;
}