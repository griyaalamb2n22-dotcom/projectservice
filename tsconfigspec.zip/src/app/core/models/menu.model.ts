// src/app/core/models/menu.model.ts
export interface MenuItem {
  label: string;
  icon?: string;
  route?: string;
  badge?: string;
  expanded?: boolean;
  children?: MenuItem[];
}