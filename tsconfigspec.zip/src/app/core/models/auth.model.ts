// src/app/core/models/auth.model.ts
export interface LoginRequest {
  username: string;
  password: string;
  rememberMe?: boolean;
}

export interface AuthUser {
  id: number;
  username: string;
  fullName: string;
  email: string;
  role: string;
  avatar?: string;
  permissions?: string[];
}

export interface LoginResponse {
  accessToken: string;
  refreshToken?: string;
  expiresIn?: number;
  user: AuthUser;
}