// src/app/core/models/dashboard.model.ts
export interface DashboardStat {
  title: string;
  value: string;
  delta: string;
  positive: boolean;
}

export interface RevenuePoint {
  label: string;
  amount: number;
}