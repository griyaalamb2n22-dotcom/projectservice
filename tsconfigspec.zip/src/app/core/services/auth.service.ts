// src/app/core/services/auth.service.ts
import { Injectable, computed, inject, signal } from '@angular/core';
import { Observable, of, delay, tap } from 'rxjs';
import { AuthUser, LoginRequest, LoginResponse } from '../models/auth.model';
import { StorageService } from './storage.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly storage = inject(StorageService);

  private readonly _currentUser = signal<AuthUser | null>(
    this.storage.getUser()
  );

  private readonly _accessToken = signal<string | null>(
    this.storage.getAccessToken()
  );

  readonly currentUser = this._currentUser.asReadonly();
  readonly accessToken = this._accessToken.asReadonly();

  readonly isAuthenticated = computed(() => !!this._accessToken());

  readonly userRole = computed(() => this._currentUser()?.role ?? null);

  readonly permissions = computed(() => this._currentUser()?.permissions ?? []);

  login(payload: LoginRequest): Observable<LoginResponse> {
    const response: LoginResponse = {
      accessToken: 'mock-access-token',
      refreshToken: 'mock-refresh-token',
      expiresIn: 3600,
      user: {
        id: 1,
        username: payload.username,
        fullName: 'Demo Administrator',
        email: 'admin@example.com',
        role: 'Admin',
        avatar: '',
        permissions: ['dashboard.view', 'report.download']
      }
    };

    return of(response).pipe(
      delay(500),
      tap((res) => this.setSession(res))
    );
  }

  logout(): void {
    this.clearSession();
  }

  getCurrentUser(): AuthUser | null {
    return this._currentUser();
  }

  getAccessToken(): string | null {
    return this._accessToken();
  }

  hasRole(role: string): boolean {
    return this._currentUser()?.role === role;
  }

  hasAnyRole(roles: string[]): boolean {
    const currentRole = this._currentUser()?.role;
    return !!currentRole && roles.includes(currentRole);
  }

  hasPermission(permission: string): boolean {
    return this._currentUser()?.permissions?.includes(permission) ?? false;
  }

  hasAnyPermission(permissions: string[]): boolean {
    const userPermissions = this._currentUser()?.permissions ?? [];
    return permissions.some(permission => userPermissions.includes(permission));
  }

  restoreSession(): void {
    this._accessToken.set(this.storage.getAccessToken());
    this._currentUser.set(this.storage.getUser());
  }

  private setSession(response: LoginResponse): void {
    this.storage.setAccessToken(response.accessToken);

    if (response.refreshToken) {
      this.storage.setRefreshToken(response.refreshToken);
    }

    this.storage.setUser(response.user);
    this._accessToken.set(response.accessToken);
    this._currentUser.set(response.user);
  }

  private clearSession(): void {
    this.storage.clearAuth();
    this._accessToken.set(null);
    this._currentUser.set(null);
  }
}