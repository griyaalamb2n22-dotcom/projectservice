// src/app/core/services/app-state.service.ts
import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppStateService {
  sidebarCollapsed = signal(false);
  darkMode = signal(false);

  toggleSidebar(): void {
    this.sidebarCollapsed.update(value => !value);
  }

  setSidebarCollapsed(value: boolean): void {
    this.sidebarCollapsed.set(value);
  }

  toggleDarkMode(): void {
    this.darkMode.update(value => !value);
  }

  setDarkMode(value: boolean): void {
    this.darkMode.set(value);
  }
}