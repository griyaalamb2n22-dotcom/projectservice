// src/app/core/services/dashboard.service.ts
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { DashboardStat, RevenuePoint } from '../models/dashboard.model';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  getStats(): Observable<DashboardStat[]> {
    return of([
      { title: 'NEW CUSTOMERS', value: '3,897', delta: '+3.3%', positive: true },
      { title: 'NEW ORDERS', value: '35,084', delta: '-2.8%', positive: false },
      { title: 'GROWTH', value: '89.87%', delta: '+2.8%', positive: true }
    ]);
  }

  getRevenueSeries(): Observable<RevenuePoint[]> {
    return of([
      { label: 'Jan', amount: 49 },
      { label: 'Feb', amount: 61 },
      { label: 'Mar', amount: 48 },
      { label: 'Apr', amount: 57 },
      { label: 'May', amount: 63 },
      { label: 'Jun', amount: 52 },
      { label: 'Jul', amount: 28 },
      { label: 'Aug', amount: 34 },
      { label: 'Sep', amount: 22 },
      { label: 'Oct', amount: 18 },
      { label: 'Nov', amount: 31 },
      { label: 'Dec', amount: 38 }
    ]);
  }
}