// src/app/core/services/user.service.ts
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { UserProfile } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  getProfile(): Observable<UserProfile> {
    return of({
      id: 1,
      username: 'admin',
      fullName: 'Demo Administrator',
      email: 'admin@example.com',
      role: 'Admin',
      language: 'English',
      phone: '+62 8123456789',
      address: 'Banten, Indonesia'
    });
  }
}