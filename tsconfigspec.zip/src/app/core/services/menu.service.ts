// src/app/core/services/menu.service.ts
import { Injectable } from '@angular/core';
import { MenuItem } from '../models/menu.model';

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  getMenus(): MenuItem[] {
    return [
      {
        label: 'Dashboard',
        icon: 'home',
        route: '/'
      },
      {
        label: 'Email',
        icon: 'mail',
        route: '/email'
      },
      {
        label: 'Chat',
        icon: 'message-square',
        route: '/chat'
      },
      {
        label: 'Calendar',
        icon: 'calendar',
        route: '/calendar',
        badge: 'Event'
      },
      {
        label: 'UI Kit',
        icon: 'layers',
        expanded: true,
        children: [
          { label: 'Accordion', route: '/ui/accordion' },
          { label: 'Alerts', route: '/ui/alerts' },
          { label: 'Badges', route: '/ui/badges' },
          { label: 'Breadcrumbs', route: '/ui/breadcrumbs' },
          { label: 'Buttons', route: '/ui/buttons' }
        ]
      }
    ];
  }
}