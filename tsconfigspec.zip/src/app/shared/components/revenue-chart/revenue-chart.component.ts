// src/app/shared/components/revenue-chart/revenue-chart.component.ts
import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { RevenuePoint } from '../../../core/models/dashboard.model';

@Component({
  selector: 'app-revenue-chart',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './revenue-chart.component.html',
  styleUrl: './revenue-chart.component.scss'
})
export class RevenueChartComponent {
  @Input() title = 'REVENUE';
  @Input() description = '';
  @Input() selectedRange: 'Today' | 'Week' | 'Month' | 'Year' = 'Month';
  @Input() data: RevenuePoint[] = [];

  @Output() rangeChange = new EventEmitter<'Today' | 'Week' | 'Month' | 'Year'>();

  readonly ranges: ('Today' | 'Week' | 'Month' | 'Year')[] = ['Today', 'Week', 'Month', 'Year'];

  onRangeClick(range: 'Today' | 'Week' | 'Month' | 'Year'): void {
    this.rangeChange.emit(range);
  }

  trackByLabel(_: number, item: RevenuePoint): string {
    return item.label;
  }

  getBarLeft(index: number): number {
    return (100 / this.data.length) * (index + 0.5);
  }
}