// src/app/shared/components/stat-card/stat-card.component.ts
import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-stat-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './stat-card.component.html',
  styleUrl: './stat-card.component.scss'
})
export class StatCardComponent {
  @Input() title = '';
  @Input() value = '';
  @Input() delta = '';
  @Input() positive = true;
  @Input() chartType: 'line' | 'bar' = 'line';
}