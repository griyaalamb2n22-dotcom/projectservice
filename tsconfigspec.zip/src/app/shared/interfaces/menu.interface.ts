// src/app/shared/interfaces/menu.interface.ts
export interface MenuChild {
  label: string;
  route: string;
}

export interface MenuItem {
  label: string;
  icon: string;
  route?: string;
  badge?: string;
  children?: MenuChild[];
}

export interface MenuSection {
  title: string;
  items: MenuItem[];
}