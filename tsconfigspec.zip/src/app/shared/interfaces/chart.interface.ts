// src/app/shared/interfaces/chart.interface.ts
export type RevenueRange = 'Today' | 'Week' | 'Month' | 'Year';

export interface RevenueChartPoint {
  label: string;
  amount: number;
}

export interface RevenueChartData {
  title: string;
  description: string;
  selectedRange: RevenueRange;
  data: RevenueChartPoint[];
}