// src/app/shared/interfaces/layout.interface.ts
export interface HeaderActionButton {
  label: string;
  icon?: string;
  variant?: 'outline' | 'primary' | 'ghost';
  value?: string;
  disabled?: boolean;
}

export interface TopbarActionItem {
  icon: string;
  badge?: boolean;
  ariaLabel: string;
}

export interface UserMenuInfo {
  fullName: string;
  role: string;
  avatar?: string;
  initials?: string;
}