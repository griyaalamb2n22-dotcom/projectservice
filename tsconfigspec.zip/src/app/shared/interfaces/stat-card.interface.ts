// src/app/shared/interfaces/stat-card.interface.ts
export type StatChartType = 'line' | 'bar';

export interface StatCardData {
  title: string;
  value: string;
  delta: string;
  positive: boolean;
  chartType?: StatChartType;
}