export interface CertificateHeader {
  memberID: string;
  companyID: string;
  policyID: string;
  policyOwnerName?: string;
  productType?: string;
  productTypeName?: string;
  partnerID?: string;
  partnerName?: string;
  certificateID: string;
  insuredID?: string;
  insuredName?: string;
  debiturID?: string;
  debiturName?: string;
  certificateStatus?: string;
  certificateStatusName?: string;
  underwritingStatus?: string;
  underwritingStatusName?: string;
  pendingTransNo?: string;
  pendingTransType?: string;
  pendingTransTypeName?: string;
  progressStatus?: string;
  progressStatusName?: string;
  medicalType?: string;
  pendingItem?: string;
  medicalTypeName?: string;
}

export interface CertificateInfo {
  memberID: string;
  applicationNo?: string;
  effectiveDate?: string;
  appReceiveDate?: string;
  appSignedDate?: string;
  coverNoteDate?: string;
  joinIncome?: boolean;
  mainCertificateID?: string;
  currency?: string;
  billingMode?: string;
  premiumAmount?: number;
  premiumNettAmount?: number;
  premiumTaxAmount?: number;
  premiumTaxRate?: number;
  agreementNo?: string;
  loanDuration?: number;
  loanMaturityDate?: string;
  billAmount?: number;
  extraPremiumRate?: string;
  extraPremiumAmount?: number;
  extraPremiumNett?: number;
  totalPremium?: number;
  extraMortalityRating?: number;
  allowedProcess?: number;
  inforceDate?: string;
  weight?: number;
  height?: number;
  bmiRate?: number;
  rating?: number;
  prevCertificateID?: string;
  surrenderAmount?: number;
  needUnderwritingProcess?: boolean;
  notes?: string;
}

export interface CertificateDetailResponse {
  header: CertificateHeader;
  certInfo: CertificateInfo;
}

export interface ClientAgentBeneficiaryInfo {
  memberID: string;
  insuredID?: string;
  insuredName?: string;
  insuredIDNo?: string;
  insuredBirthDate?: string;
  insuredGender?: string;
  agentID?: string;
  agentName?: string;
  beneficiaryName?: string;
  beneficiaryRelation?: string;
  beneficiaryPercentage?: number;
}

export interface CoverageDocumentInfo {
  memberID: string;
  planType?: string;
  planName?: string;
  sumInsured?: number;
  documentName?: string;
  documentStatus?: string;
  documentDate?: string;
}

export interface FinancialHealthInfo {
  memberID: string;
  loanAmount?: number;
  outstandingAmount?: number;
  healthDeclaration?: string;
  medicalResult?: string;
}

export interface PolicyHistoryItem {
  memberID: string;
  transactionID?: string;
  transactionName?: string;
  transactionDate?: string;
  remarks?: string;
}

export interface LetterItem {
  memberID: string;
  letterType?: string;
  letterName?: string;
  letterDate?: string;
  status?: string;
}

export interface ActivityHistoryItem {
  memberID: string;
  activityType?: string;
  description?: string;
  activityDate?: string;
  userID?: string;
}