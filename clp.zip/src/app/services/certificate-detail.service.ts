import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  CertificateDetailResponse, ClientAgentBeneficiaryInfo, CoverageDocumentInfo,
  FinancialHealthInfo, PolicyHistoryItem, LetterItem, ActivityHistoryItem
} from '../models/certificate-detail.model';

@Injectable({ providedIn: 'root' })
export class CertificateDetailService {
  private http = inject(HttpClient);
  private baseUrl = 'https://localhost:7201/api/certificate';

  getDetail(certificateID: string): Observable<CertificateDetailResponse> {
    return this.http.get<CertificateDetailResponse>(`${this.baseUrl}/${certificateID}/detail`);
  }

  getClientAgentBeneficiary(memberID: string): Observable<ClientAgentBeneficiaryInfo> {
    return this.http.get<ClientAgentBeneficiaryInfo>(`${this.baseUrl}/${memberID}/client-agent-beneficiary`);
  }

  getCoverageDocument(memberID: string): Observable<CoverageDocumentInfo[]> {
    return this.http.get<CoverageDocumentInfo[]>(`${this.baseUrl}/${memberID}/coverage-document`);
  }

  getFinancialHealth(memberID: string): Observable<FinancialHealthInfo> {
    return this.http.get<FinancialHealthInfo>(`${this.baseUrl}/${memberID}/financial-health`);
  }

  getPolicyHistory(memberID: string): Observable<PolicyHistoryItem[]> {
    return this.http.get<PolicyHistoryItem[]>(`${this.baseUrl}/${memberID}/policy-history`);
  }

  getLetters(memberID: string): Observable<LetterItem[]> {
    return this.http.get<LetterItem[]>(`${this.baseUrl}/${memberID}/letters`);
  }

  getActivityHistory(memberID: string): Observable<ActivityHistoryItem[]> {
    return this.http.get<ActivityHistoryItem[]>(`${this.baseUrl}/${memberID}/activity-history`);
  }
}