import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CertificateDetailService } from '../../services/certificate-detail.service';
import {
  CertificateHeader, CertificateInfo, ClientAgentBeneficiaryInfo, CoverageDocumentInfo,
  FinancialHealthInfo, PolicyHistoryItem, LetterItem, ActivityHistoryItem
} from '../../models/certificate-detail.model';

type TabKey = 'certInfo' | 'clientAgent' | 'coverage' | 'financial' | 'policyHistory' | 'letters' | 'activity';

@Component({
  selector: 'app-certificate-detail',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './certificate-detail.component.html',
  styleUrl: './certificate-detail.component.css'
})
export class CertificateDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private svc = inject(CertificateDetailService);

  certificateID = signal('');
  header = signal<CertificateHeader | null>(null);
  certInfo = signal<CertificateInfo | null>(null);
  clientAgent = signal<ClientAgentBeneficiaryInfo | null>(null);
  coverage = signal<CoverageDocumentInfo[]>([]);
  financial = signal<FinancialHealthInfo | null>(null);
  policyHistory = signal<PolicyHistoryItem[]>([]);
  letters = signal<LetterItem[]>([]);
  activity = signal<ActivityHistoryItem[]>([]);

  isLoading = signal(false);
  errorMessage = signal('');
  activeTab = signal<TabKey>('certInfo');

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('certificateID');
    if (id) {
      this.certificateID.set(id);
      this.loadHeaderAndCertInfo(id);
    }
  }

  loadHeaderAndCertInfo(certificateID: string): void {
    this.isLoading.set(true);
    this.errorMessage.set('');
    this.svc.getDetail(certificateID).subscribe({
      next: (res) => {
        this.header.set(res.header);
        this.certInfo.set(res.certInfo);
        this.isLoading.set(false);
        this.setTab('certInfo');
      },
      error: (err) => {
        this.errorMessage.set(err?.error?.message ?? 'Failed to load certificate detail');
        this.isLoading.set(false);
      }
    });
  }

  setTab(tab: TabKey): void {
    this.activeTab.set(tab);
    const memberID = this.header()?.memberID;
    if (!memberID) return;

    switch (tab) {
      case 'clientAgent':
        if (!this.clientAgent()) {
          this.svc.getClientAgentBeneficiary(memberID).subscribe(d => this.clientAgent.set(d));
        }
        break;
      case 'coverage':
        if (this.coverage().length === 0) {
          this.svc.getCoverageDocument(memberID).subscribe(d => this.coverage.set(d));
        }
        break;
      case 'financial':
        if (!this.financial()) {
          this.svc.getFinancialHealth(memberID).subscribe(d => this.financial.set(d));
        }
        break;
      case 'policyHistory':
        if (this.policyHistory().length === 0) {
          this.svc.getPolicyHistory(memberID).subscribe(d => this.policyHistory.set(d));
        }
        break;
      case 'letters':
        if (this.letters().length === 0) {
          this.svc.getLetters(memberID).subscribe(d => this.letters.set(d));
        }
        break;
      case 'activity':
        if (this.activity().length === 0) {
          this.svc.getActivityHistory(memberID).subscribe(d => this.activity.set(d));
        }
        break;
    }
  }

  goBack(): void {
    this.router.navigate(['/certificate-list']);
  }

  getStatusClass(status: string | null | undefined): string {
    const map: Record<string, string> = {
      ACT: 'status-active', LAP: 'status-lapsed', TRM: 'status-terminated', PND: 'status-pending'
    };
    return map[status ?? ''] ?? 'status-secondary';
  }
}