﻿using ICLIPS_API.Models;
using ICLIPS_API.DTOs;

namespace ICLIPS_API.Repositories
{
    public interface ICertificateDetailRepository
    {
        Task<PagedResult<CertificateDto>> GetCertificateListAsync(CertificateFilterDto filter);
        Task<CertificateDto?> GetByMemberIdAsync(string memberId, string companyId);

        Task<CertificateHeader?> GetHeaderAsync(string certificateID);
        Task<CertificateInfo?> GetCertificateInfoAsync(string memberID);

        Task<ClientInfo?> GetClientInfoAsync(string clientID);
        Task<AgentInfo?> GetAgentInfoAsync(string companyID, string policyID, string agentID);

        Task<List<ProductPackageOption>> GetProductPackageOptionsAsync(string companyID, string? productPackageID);
        Task<List<CoverageDocumentInfo>> GetCoverageDocumentAsync(string companyID, string productPackageID, string memberID);

        Task<List<HealthQuestionInfo>> GetFinancialHealthAsync(string companyID, string productID, string policyID, string memberID);

        Task<List<ProductAppliedItem>> GetPolicyHistoryProductAppliedAsync(string memberID);
        Task<List<PolicyHistoryItem>> GetPolicyHistoryAsync(string memberID);

        Task<List<LetterItem>> GetLettersAsync(string memberID);
        Task<List<ActivityHistoryItem>> GetActivityHistoryAsync(string memberID);
    }
}