﻿using Microsoft.AspNetCore.Mvc;
using ICLIPS_API.Repositories;
using ICLIPS_API.DTOs;

namespace ICLIPS_API.Controllers
{
    [ApiController]
    [Route("api/certificate")]
    public class CertificateController : ControllerBase
    {
        private readonly ICertificateDetailRepository _repo;

        public CertificateController(ICertificateDetailRepository repo) => _repo = repo;

        [HttpGet]
        public async Task<IActionResult> GetList([FromQuery] CertificateFilterDto filter)
            => Ok(await _repo.GetCertificateListAsync(filter));

        [HttpGet("by-member")]
        public async Task<IActionResult> GetByMember([FromQuery] string memberId, [FromQuery] string companyId)
        {
            var result = await _repo.GetByMemberIdAsync(memberId, companyId);
            return result == null ? NotFound() : Ok(result);
        }

        [HttpGet("{certificateID}/detail")]
        public async Task<IActionResult> GetDetail(string certificateID)
        {
            try
            {
                var header = await _repo.GetHeaderAsync(certificateID);
                if (header == null) return NotFound(new { message = "Certificate not found" });

                var certInfo = await _repo.GetCertificateInfoAsync(header.MemberID);
                return Ok(new { header, certInfo });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }

        // ── Client, Agent & Beneficiary ─────────────────────────
        [HttpGet("client/{clientID}")]
        public async Task<IActionResult> GetClientInfo(string clientID)
            => Ok(await _repo.GetClientInfoAsync(clientID));

        [HttpGet("agent")]
        public async Task<IActionResult> GetAgentInfo([FromQuery] string companyID, [FromQuery] string policyID, [FromQuery] string agentID)
            => Ok(await _repo.GetAgentInfoAsync(companyID, policyID, agentID));

        // ── Coverage & Document ─────────────────────────────────
        [HttpGet("product-package")]
        public async Task<IActionResult> GetProductPackageOptions([FromQuery] string companyID, [FromQuery] string? productPackageID)
            => Ok(await _repo.GetProductPackageOptionsAsync(companyID, productPackageID));

        [HttpGet("{memberID}/coverage-document")]
        public async Task<IActionResult> GetCoverageDocument(string memberID, [FromQuery] string companyID, [FromQuery] string productPackageID)
            => Ok(await _repo.GetCoverageDocumentAsync(companyID, productPackageID, memberID));

        // ── Financial & Health ───────────────────────────────────
        [HttpGet("{memberID}/financial-health")]
        public async Task<IActionResult> GetFinancialHealth(string memberID, [FromQuery] string companyID, [FromQuery] string productID, [FromQuery] string policyID)
            => Ok(await _repo.GetFinancialHealthAsync(companyID, productID, policyID, memberID));

        // ── Policy History ───────────────────────────────────────
        [HttpGet("{memberID}/policy-history/product-applied")]
        public async Task<IActionResult> GetProductApplied(string memberID)
            => Ok(await _repo.GetPolicyHistoryProductAppliedAsync(memberID));

        [HttpGet("{memberID}/policy-history")]
        public async Task<IActionResult> GetPolicyHistory(string memberID)
            => Ok(await _repo.GetPolicyHistoryAsync(memberID));

        // ── Letters ───────────────────────────────────────────────
        [HttpGet("{memberID}/letters")]
        public async Task<IActionResult> GetLetters(string memberID)
            => Ok(await _repo.GetLettersAsync(memberID));

        // ── Activity History ──────────────────────────────────────
        [HttpGet("{memberID}/activity-history")]
        public async Task<IActionResult> GetActivityHistory(string memberID)
            => Ok(await _repo.GetActivityHistoryAsync(memberID));
    }
}