﻿namespace ICLIPS_API.Models
{
    public class CertificateHeader
    {
        public string MemberID { get; set; } = "";
        public string? CompanyID { get; set; }
        public string? PolicyID { get; set; }
        public string? PolicyOwnerName { get; set; }
        public string? ProductType { get; set; }
        public string? ProductTypeName { get; set; }
        public string? PartnerID { get; set; }
        public string? PartnerName { get; set; }
        public string CertificateID { get; set; } = "";
        public string? InsuredID { get; set; }
        public string? InsuredName { get; set; }
        public string? DebiturID { get; set; }
        public string? DebiturName { get; set; }
        public string? CertificateStatus { get; set; }
        public string? CertificateStatusName { get; set; }
        public string? UnderwritingStatus { get; set; }
        public string? UnderwritingStatusName { get; set; }
        public string? PendingTransNo { get; set; }
        public string? PendingTransType { get; set; }
        public string? PendingTransTypeName { get; set; }
        public string? ProgressStatus { get; set; }
        public string? ProgressStatusName { get; set; }
        public string? MedicalType { get; set; }
        public string? PendingItem { get; set; }
        public string? MedicalTypeName { get; set; }
    }

    public class CertificateInfo
    {
        public string MemberID { get; set; } = "";
        public string? ApplicationNo { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? AppReceiveDate { get; set; }
        public DateTime? AppSignedDate { get; set; }
        public DateTime? CoverNoteDate { get; set; }
        public bool? JoinIncome { get; set; }
        public string? MainCertificateID { get; set; }
        public string? Currency { get; set; }
        public string? BillingMode { get; set; }
        public decimal? BillAmount { get; set; }
        public decimal? PremiumNettAmount { get; set; }
        public decimal? PremiumTaxAmount { get; set; }
        public decimal? PremiumTaxRate { get; set; }
        public string? ExtraPremiumRate { get; set; }
        public decimal? ExtraPremiumAmount { get; set; }
        public decimal? ExtraPremiumNett { get; set; }
        public decimal? TotalPremium { get; set; }
        public int? AllowedProcess { get; set; }
        public DateTime? InforceDate { get; set; }
        public string? AgreementNo { get; set; }
        public int? LoanDuration { get; set; }
        public DateTime? LoanMaturityDate { get; set; }
        public decimal? Weight { get; set; }
        public decimal? Height { get; set; }
        public decimal? BMIRate { get; set; }
        public int? Rating { get; set; }
        public string? PrevCertificateID { get; set; }
        public decimal? SurrenderAmount { get; set; }
        public bool? NeedUnderwritingProcess { get; set; }
        public string? Notes { get; set; }
        public string? BasePlan { get; set; }
        public decimal? ExtraMortalityRating { get; set; }
    }

    // ── Client Info (tclient) ────────────────────────────────
    public class ClientInfo
    {
        public string? CompanyID { get; set; }
        public string? ClientID { get; set; }
        public string? AlternateID { get; set; }
        public string? ClientType { get; set; }
        public string? ClientName { get; set; }
        public string? NameType { get; set; }
        public string? AliasName { get; set; }
        public string? Citizenship { get; set; }
        public string? IDType { get; set; }
        public string? IDNumber { get; set; }
        public DateTime? IDExpireDate { get; set; }
        public string? Sex { get; set; }
        public string? BirthPlace { get; set; }
        public DateTime? BirthDate { get; set; }
        public string? MaritalStatus { get; set; }
        public string? Religion { get; set; }
        public string? CompanyName { get; set; }
        public string? CompanyBizLine { get; set; }
        public string? JobTitle { get; set; }
        public string? JobDescription { get; set; }
        public string? OfficeAddress { get; set; }
        public string? OfficeDistrict { get; set; }
        public string? OfficeCity { get; set; }
        public string? OfficePostalCode { get; set; }
        public string? OfficePhone { get; set; }
        public string? OfficeFax { get; set; }
        public string? HomeAddress { get; set; }
        public string? HomeDistrict { get; set; }
        public string? HomeCity { get; set; }
        public string? HomePostalCode { get; set; }
        public string? HomePhone { get; set; }
        public string? HomeFax { get; set; }
        public string? LivingAddress { get; set; }
        public string? LivingDistrict { get; set; }
        public string? LivingCity { get; set; }
        public string? LivingPostalCode { get; set; }
        public string? LivingPhone { get; set; }
        public string? LivingFax { get; set; }
        public string? EmailAddress { get; set; }
        public string? MobileNumber { get; set; }
        public string? TaxNumber { get; set; }
    }

    // ── Agent Info ────────────────────────────────────────────
    public class AgentInfo
    {
        public string? PolicyID { get; set; }
        public string? CompanyID { get; set; }
        public string? AgentID { get; set; }
        public string? AgentName { get; set; }
        public string? BranchID { get; set; }
        public string? BranchName { get; set; }
        public string? MainBranchID { get; set; }
        public string? MainBranchName { get; set; }
        public string? AreaID { get; set; }
        public string? AreaName { get; set; }
        public string? CredamID { get; set; }
        public string? CredamName { get; set; }
        public string? AgentStatus { get; set; }
    }

    public class ClientAgentBeneficiaryInfo
    {
        public ClientInfo? InsuredClient { get; set; }
        public ClientInfo? DebiturClient { get; set; }
        public AgentInfo? Agent { get; set; }
    }

    // ── Coverage & Document ──────────────────────────────────
    public class ProductPackageOption
    {
        public string? CompanyID { get; set; }
        public string? ProductPackageID { get; set; }
        public string? ProductPackageName { get; set; }
    }

    public class CoverageDocumentInfo
    {
        public int CertificateCoverageID { get; set; }
        public string? PlanID { get; set; }
        public string? PlanName { get; set; }
        public decimal? FaceAmount { get; set; }
        public int? CoverageDuration { get; set; }
        public string? DurationUnit { get; set; }
        public string? DurationUnitName { get; set; }
        public DateTime? CoverageEffectiveDate { get; set; }
        public DateTime? CoverageMaturityDate { get; set; }
        public int? PlanSequence { get; set; }
        public string? ProductPackageID { get; set; }
    }

    // ── Financial & Health ────────────────────────────────────
    public class HealthQuestionInfo
    {
        public string? NoUrut { get; set; }
        public string? HealthQueID { get; set; }
        public string? HealthQueDesc { get; set; }
        public string? IsAnswer { get; set; }
        public int? Answer { get; set; }
        public string? Explaination { get; set; }
    }

    // ── Policy History ────────────────────────────────────────
    public class ProductAppliedItem
    {
        public int IsUsed { get; set; }
        public string? DataSource { get; set; }
        public string? CompanyID { get; set; }
        public string? CompanyName { get; set; }
        public string? PolicyID { get; set; }
        public string? PlanID { get; set; }
        public string? PlanName { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public decimal? FaceAmount { get; set; }
        public string? CvgNum { get; set; }
    }

    public class PolicyHistoryItem
    {
        public string MemberID { get; set; } = "";
        public string? TransactionID { get; set; }
        public string? TransactionName { get; set; }
        public DateTime? TransactionDate { get; set; }
        public string? Remarks { get; set; }
    }

    // ── Letters ───────────────────────────────────────────────
    public class LetterItem
    {
        public string? TransReportID { get; set; }
        public string? ReportID { get; set; }
        public string? ReportName { get; set; }
        public DateTime? ReportDate { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string? ReportLink { get; set; }
        public string? Notes { get; set; }
    }

    // ── Activity History ──────────────────────────────────────
    public class ActivityHistoryItem
    {
        public string? HistoryID { get; set; }
        public DateTime? HistoryDate { get; set; }
        public string? HistoryType { get; set; }
        public string? HistoryBy { get; set; }
        public string? HistoryNotes { get; set; }
    }
}