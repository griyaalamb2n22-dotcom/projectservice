export interface Certificate {
  // ── Identity ─────────────────────────────────────
  memberID:              string | null;
  companyID:             string | null;
  policyID:              string | null;
  certificateID:         string | null;

  // ── Certificate Status ────────────────────────────
  certificateStatus:     string | null;
  certificateStatusName: string | null;

  // ── Insured ───────────────────────────────────────
  insuredID:             string | null;
  insuredName:           string | null;

  // ── Product ───────────────────────────────────────
  productTypeName:       string | null;
  productType:           string | null;

  // ── Policy Owner ──────────────────────────────────
  policyOwnerName:       string | null;

  // ── Dates (ISO string dari JSON) ──────────────────
  appReceiveDate:        string | null;
  effectiveDate:         string | null;
  inforceDate:           string | null;
  terminateDate:         string | null;

  // ── Pending ───────────────────────────────────────
  pendingItem:           string | null;

  // ── Progress Status ───────────────────────────────
  progressStatus:        string | null;
  progressStatusName:    string | null;
}

export interface CertificateFilter {
  memberID?:          string;
  companyID?:         string;
  policyID?:          string;
  certificateID?:     string;
  certificateStatus?: string;
  insuredName?:       string;   // ← sesuai @InsuredName di SP

  pageNumber:    number;
  pageSize:      number;
  sortColumn:    string;
  sortDirection: 'ASC' | 'DESC';
}

export interface PagedResult<T> {
  data:         T[];
  totalRecords: number;
  pageNumber:   number;
  pageSize:     number;
  totalPages:   number;
  hasPrevious:  boolean;
  hasNext:      boolean;
}