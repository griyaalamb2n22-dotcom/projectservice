import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CodeOption } from '../models/code.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class CodeService {
  private http = inject(HttpClient);
  private base = `${environment.apiUrl}/api/code`;

  getCodes(companyId: string, codeType: string, codeCategory = ''): Observable<CodeOption[]> {
    return this.http.get<CodeOption[]>(this.base, {
      params: { companyId, codeType, codeCategory }
    });
  }
}