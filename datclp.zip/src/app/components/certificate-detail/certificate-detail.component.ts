import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CertificateDetailService } from '../../services/certificate-detail.service';
import {
  CertificateHeader, CertificateInfo, ClientInfo, AgentInfo, ProductPackageOption,
  CoverageDocumentInfo, HealthQuestionInfo, ProductAppliedItem,
  PolicyHistoryItem, LetterItem, ActivityHistoryItem
} from '../../models/certificate-detail.model';

type TabKey = 'certInfo' | 'clientAgent' | 'coverage' | 'financial' | 'policyHistory' | 'letters' | 'activity';

@Component({
  selector: 'app-certificate-detail',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './certificate-detail.component.html',
  styleUrl: './certificate-detail.component.css'
})
export class CertificateDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private svc = inject(CertificateDetailService);

  certificateID = signal('');
  header = signal<CertificateHeader | null>(null);
  certInfo = signal<CertificateInfo | null>(null);

  insuredClient = signal<ClientInfo | null>(null);
  debiturClient = signal<ClientInfo | null>(null);
  agent = signal<AgentInfo | null>(null);

  packageOptions = signal<ProductPackageOption[]>([]);
  coverage = signal<CoverageDocumentInfo[]>([]);

  healthQuestions = signal<HealthQuestionInfo[]>([]);

  productApplied = signal<ProductAppliedItem[]>([]);
  policyHistory = signal<PolicyHistoryItem[]>([]);

  letters = signal<LetterItem[]>([]);
  activity = signal<ActivityHistoryItem[]>([]);

  isLoading = signal(false);
  errorMessage = signal('');
  activeTab = signal<TabKey>('certInfo');

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('certificateID');
    if (id) {
      this.certificateID.set(id);
      this.loadHeaderAndCertInfo(id);
    }
  }

  loadHeaderAndCertInfo(certificateID: string): void {
    this.isLoading.set(true);
    this.errorMessage.set('');
    this.svc.getDetail(certificateID).subscribe({
      next: (res) => {
        this.header.set(res.header);
        this.certInfo.set(res.certInfo);
        this.isLoading.set(false);
        this.setTab('certInfo');
      },
      error: (err) => {
        this.errorMessage.set(err?.error?.message ?? `Failed to load certificate detail (status: ${err?.status})`);
        this.isLoading.set(false);
      }
    });
  }

  setTab(tab: TabKey): void {
    this.activeTab.set(tab);
    const h = this.header();
    if (!h?.memberID) return;
    const memberID = h.memberID;
    const companyID = h.companyID ?? '01';
    const policyID = h.policyID ?? '';

    switch (tab) {
      case 'clientAgent':
        if (!this.insuredClient() && h.insuredID) {
          this.svc.getClientInfo(h.insuredID).subscribe(d => this.insuredClient.set(d));
        }
        if (!this.debiturClient() && h.debiturID) {
          this.svc.getClientInfo(h.debiturID).subscribe(d => this.debiturClient.set(d));
        }
        break;

      case 'coverage':
        if (this.coverage().length === 0) {
          this.svc.getProductPackageOptions(companyID).subscribe(opts => {
            this.packageOptions.set(opts);
            const pkgID = opts[0]?.productPackageID;
            if (pkgID) {
              this.svc.getCoverageDocument(memberID, companyID, pkgID).subscribe(d => this.coverage.set(d));
            }
          });
        }
        break;

      case 'financial':
        if (this.healthQuestions().length === 0 && h.productType) {
          this.svc.getFinancialHealth(memberID, companyID, h.productType, policyID)
            .subscribe(d => this.healthQuestions.set(d));
        }
        break;

      case 'policyHistory':
        if (this.productApplied().length === 0) {
          this.svc.getProductApplied(memberID).subscribe(d => this.productApplied.set(d));
        }
        if (this.policyHistory().length === 0) {
          this.svc.getPolicyHistory(memberID).subscribe(d => this.policyHistory.set(d));
        }
        break;

      case 'letters':
        if (this.letters().length === 0) {
          this.svc.getLetters(memberID).subscribe(d => this.letters.set(d));
        }
        break;

      case 'activity':
        if (this.activity().length === 0) {
          this.svc.getActivityHistory(memberID).subscribe(d => this.activity.set(d));
        }
        break;
    }
  }

  goBack(): void {
    this.router.navigate(['/dashboard/certificate-list']);
  }

  getStatusClass(status: string | null | undefined): string {
    const map: Record<string, string> = { ACT: 'status-active', LAP: 'status-lapsed', TRM: 'status-terminated', PND: 'status-pending' };
    return map[status ?? ''] ?? 'status-secondary';
  }
}